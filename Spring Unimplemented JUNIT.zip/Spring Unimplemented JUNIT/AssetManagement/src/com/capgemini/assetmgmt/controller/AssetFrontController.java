package com.capgemini.assetmgmt.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.assetmgmt.daos.AssetAdminDAOImpl;
import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.Status;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.dtos.UserType;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;
import com.capgemini.assetmgmt.exceptions.AssetManagerException;
import com.capgemini.assetmgmt.exceptions.AssetUserException;
import com.capgemini.assetmgmt.services.AssetAdminService;
import com.capgemini.assetmgmt.services.AssetUserService;
import com.capgemini.assetmgmt.services.AssetManagerService;

/*Front Controller to handle the request raised.*/
@Controller
public class AssetFrontController {

	@Resource(name="assetUserService")			//Autowiring the User Service Layer.
	AssetUserService userService;
	
	@Resource(name="adminService")				//Autowiring the Admin Service Layer.
	AssetAdminService adminService;
	
	@Resource(name="managerService")			//Autowiring the Manager Service Layer.
	AssetManagerService managerService;

	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	
	/*Handles the index.html request*/
	@RequestMapping("/index")					
	public String returnHomePage(){
		return "index";
	}
	
	/*Handles the getLoginForm.html request*/
	@RequestMapping("/getLoginForm")
	public String getLoginForm(Model model){
		User user = new User();
		model.addAttribute("user",user);
		return "login";
	}
	
	/*Handles the login.html request*/
	@RequestMapping("/login")
	@Scope("session")
	public String login(@ModelAttribute User user,Model model , HttpServletRequest request){
		request.getSession(true).setAttribute("user", user);
		boolean isValid=false;
		try {
			isValid=userService.isValidUser(user);
			if(isValid){
				model.addAttribute("user",user);
				if((user.getUserType().toString()).equals("admin")){
					return "menuForAdmin";
				}
				else if((user.getUserType().toString()).equals("manager")){
					return "menuForManager";
				}
			}
		} catch (AssetUserException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "login";
		}
		model.addAttribute("errorMessage","Can not validate the user");
		return "login";
	}
	
	/*Handles the logout.html request*/
	@RequestMapping("/logout")
	public String logout(Model model, HttpServletRequest request){
		HttpSession session = request.getSession(false);
		
		if(session != null){
			session.invalidate();
		}
		return "index";
	}
	
	/*Handles the getAddAssetForm.html request*/
	@RequestMapping("/getAddAssetForm")
	public String getAddAssetForm(Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		Asset asset = new Asset();
		model.addAttribute(asset);
		return "addAssetAdmin";
	}
	
	/*Handles the home.html request*/
	@RequestMapping("/home")
	public String getHomePage(Model model, HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		User user = (User) request.getSession(false).getAttribute("user");
		if((user.getUserType().toString()).equals(UserType.admin.toString())){
			return "menuForAdmin";
		}
		else if((user.getUserType().toString()).equals(UserType.manager.toString())){
			return "menuForManager";
		}
		return "index";
	}
	
	/*Handles the addAssetAdmin.html request*/
	@RequestMapping("/addAssetAdmin")
	public String addAssetAdmin(@ModelAttribute @Valid Asset asset ,BindingResult result , Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		if(result.hasErrors()){
			return "addAssetAdmin";
		}
		try {
			int assetId = adminService.addAsset(asset);
			model.addAttribute("assetId",assetId);
		} catch (AssetAdminException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "addAssetAdmin";
		}
		return "assetAddedAdmin";
	}
	
	/*Handles the getUpdateAssetForm.html request*/
	@RequestMapping("/getUpdateAssetForm")
	public String getUpdateAssetForm(Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		Asset asset = new Asset();
		model.addAttribute("asset",asset);
		return "updateAssetAdmin";
	}

	/*Handles the fetchAssetAdmin.html request*/
	@RequestMapping("/fetchAssetAdmin")
	public String fetchAssetAdmin(@ModelAttribute Asset asset , Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		int assetId = asset.getAssetId();
		try {
			asset = adminService.searchAsset(assetId);
			model.addAttribute("asset",asset);
		} catch (AssetAdminException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "updateAssetAdmin";
		}
		return "updateAssetAdmin";
	}

	/*Handles the updateAssetAdmin.html request*/
	@RequestMapping("/updateAssetAdmin")
	public String updateAssetAdmin(@ModelAttribute Asset asset , Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		try {
			adminService.updateAsset(asset);
		} catch (AssetAdminException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage1",e.getMessage());
			return "updateAssetAdmin";
		}
		return "menuForAdmin";
	}

	/*Handles the displayRequestAdmin.html request*/
	@RequestMapping("/displayRequestAdmin")
	public String displayRequestAdmin(Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		try {
			List<AssetAllocation> requestList = adminService.displayRequest();
			model.addAttribute("requestList",requestList);
		} catch (AssetAdminException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "requestListAdmin";
		}
		return "requestListAdmin";
	}

	/*Handles the viewAllAsset.html request*/
	@RequestMapping("/viewAllAsset")
	public String viewAllAsset(Model model,HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		try {
			List<Asset> assetList = managerService.listAsset();
			model.addAttribute("assetList",assetList);
		} catch (AssetManagerException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "getAllAssetManager";
		}
		return "getAllAssetManager";
	}

	/*Handles the getRequestForm.html request*/
	@RequestMapping("/getRequestForm")
	public String getRequestForm(Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		User user = (User) request.getSession(false).getAttribute("user");
		Asset asset = new Asset();
		AssetAllocation assetAllocation = new AssetAllocation();
		assetAllocation.setAsset(asset);
		model.addAttribute("assetAllocation",assetAllocation);
		try {
			List<Employee> employeeList = managerService.fetchEmployeeList(user.getUserId());
			model.addAttribute("employeeList",employeeList);
			request.getSession(false).setAttribute("employeeList", employeeList);
		} catch (AssetManagerException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "oops";
		}
		return "raiseRequestManager";
	}

	/*Handles the postRequestRaise.html request*/
	@RequestMapping("/postRequestRaise")
	public String postRequestRaise(@ModelAttribute @Valid AssetAllocation assetAllocation ,BindingResult result, Model model , HttpServletRequest request){
		
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		if(result.hasErrors()){
			return "raiseRequestManager";
		}
		
		int flag = 0;
		@SuppressWarnings("unchecked")
		List<Employee> empList = (List<Employee>) request.getSession(false).getAttribute("employeeList");
		
		try {
			if(assetAllocation.getAllocationDate().after(assetAllocation.getReleaseDate())){
				model.addAttribute("error", "Release date is incorrect");
				model.addAttribute("assetAllocation",assetAllocation);
				return "raiseRequestManager";
			}
			for(int index=0 ; index<empList.size() ; index++){
				int empNo = empList.get(index).getEmpNo();
				if(empNo == assetAllocation.getEmpNo()){
					flag = 1;
				}
			}
			
			if(flag == 0){
				model.addAttribute("error1", "You cannot raise request for this employee");
				model.addAttribute("assetAllocation",assetAllocation);
				return "raiseRequestManager";
			}
			try{
				managerService.isValidRequestDate(assetAllocation);
			}catch(Exception e){
				myLogger.debug(e.getMessage());
				model.addAttribute("error2",e.getMessage());
				return "raiseRequestManager";
			}
			Asset asset = adminService.searchAsset(assetAllocation.getAsset().getAssetId());
			assetAllocation.setStatus(Status.inProgress);
			assetAllocation.setAsset(asset);
			int allocationId = managerService.raiseRequest(assetAllocation);
			model.addAttribute("allocationId",allocationId);
		} catch (AssetManagerException | AssetAdminException e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "raiseRequestManager";
		}
		return "postRequestManager";
	}

	/*Handles the getActionDetails.html request*/
	@RequestMapping("/getActionDetails")
	public String getActionDetails(@RequestParam("id") int allocationId , @RequestParam("action") String action , Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		if(action.equals("approve")){
			try {
				adminService.actRequestAdmin(Status.allocated.toString(), allocationId);
			} catch (AssetAdminException e) {
				myLogger.debug(e.getMessage());
				model.addAttribute("errorMessage",e.getMessage());
				return "oops";
			}
		}
		if(action.equals("reject")){
			try {
				adminService.actRequestAdmin(Status.rejected.toString(), allocationId);
			} catch (AssetAdminException e) {
				myLogger.debug(e.getMessage());
				model.addAttribute("errorMessage",e.getMessage());
				return "oops";
			}
		}
		
		return "redirect:displayRequestAdmin.html";
	}

	/*Handles the getfetchRequestForm.html request*/
	@RequestMapping("/getfetchRequestForm")
	public String getfetchRequestForm(Model model , HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		AssetAllocation assetAllocation = new AssetAllocation();
		model.addAttribute("assetAllocation", assetAllocation);
		return "fetchRequestStatusManager";
	}

	/*Handles the fetchRequsetStatus.html request*/
	@RequestMapping("/fetchRequsetStatus")
	public String fetchRequsetStatus(@ModelAttribute AssetAllocation assetAllocation ,Model model, HttpServletRequest request){
		if(request.getSession().getAttribute("user")==null){
			return "index";
		}
		try {
			User user = (User) request.getSession(false).getAttribute("user");
			assetAllocation = managerService.displayRequestStatus(assetAllocation ,user.getUserId());
			model.addAttribute("assetAllocation", assetAllocation);
		} catch (AssetManagerException
				e) {
			myLogger.debug(e.getMessage());
			model.addAttribute("errorMessage",e.getMessage());
			return "fetchRequestStatusManager";
		}
		return "fetchRequestStatusManager";
	}
}
