package com.capgemini.assetmgmt.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetManagerDAO;
import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetManagerException;

@Service("managerService")
@Transactional
public class AssetManagerServiceImpl implements AssetManagerService {

	@Resource(name="managerDao")
	AssetManagerDAO managerDAO;

	/*
	 * 1. Fetch the Employee List.
	 * 2. Fetch The list of Assets.
	 * 3. Raise the request.
	 * 4. Display request Status.
	 * 5. Find Manager
	 * 6. Check whether Date is correct or not.
	*/
	
	@Override
	public List<Asset> listAsset()
			throws AssetManagerException {
		List<Asset> myAssetList = managerDAO.listAsset();
		return myAssetList;
	}

	@Override
	public int raiseRequest(AssetAllocation assetAllocation)
			throws AssetManagerException {
		return managerDAO.raiseRequest(assetAllocation);
	}


	@Override
	public List<Employee> fetchEmployeeList(int userId)
			throws AssetManagerException {
		return managerDAO.fetchEmployeeList(userId);
	}

	@Override
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation, int userId)
			throws AssetManagerException {
		return managerDAO.displayRequestStatus(assetAllocation, userId);
	}

	@Override
	public boolean isValidRequestDate(AssetAllocation assetAllocation) throws AssetManagerException{
		return managerDAO.isValidRequestDate(assetAllocation);
	}
}
