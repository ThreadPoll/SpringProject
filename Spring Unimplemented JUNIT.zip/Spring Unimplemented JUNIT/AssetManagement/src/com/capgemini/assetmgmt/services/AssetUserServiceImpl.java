package com.capgemini.assetmgmt.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetUserDAO;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Service("assetUserService")
@Transactional
public class AssetUserServiceImpl implements AssetUserService {

	@Resource(name="assetUserDao")
	private AssetUserDAO userDAO;

	/*
	 * 1. Check the user is valid or not.
	*/
	@Override
	public boolean isValidUser(User user)
			throws AssetUserException {
		boolean isCheck = userDAO.isValidUser(user);
		return isCheck;
	}

}
