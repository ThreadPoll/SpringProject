package com.capgemini.assetmgmt.services;

import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

/*Interface for abstract methods of User Service Functions*/
public interface AssetUserService {

	public boolean isValidUser(User user) throws AssetUserException;
}
