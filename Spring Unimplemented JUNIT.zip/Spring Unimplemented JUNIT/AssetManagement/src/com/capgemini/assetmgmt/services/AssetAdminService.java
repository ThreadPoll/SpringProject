package com.capgemini.assetmgmt.services;

import java.util.List;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;

/*Interface for abstract methods of Admin Service Functions*/
public interface AssetAdminService {
	public int addAsset(Asset asset) throws AssetAdminException;
	public void updateAsset(Asset asset) throws AssetAdminException;
	public Asset searchAsset(int assetId) throws AssetAdminException;
	public List<AssetAllocation> displayRequest() throws AssetAdminException;
	public void actRequestAdmin(String status, int allocationId) throws AssetAdminException;
}
