package com.capgemini.assetmgmt.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetAdminDAO;
import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;

@Service("adminService")
@Transactional(noRollbackFor = Exception.class)
public class AssetAdminServiceImpl implements AssetAdminService {

	@Resource(name="adminDao")
	AssetAdminDAO adminDao;
	
	/*
	 * 1. Add Asset
	 * 2. Update Asset
	 * 3. Search Asset
	 * 4. Display List of Assets Requests
	 * 5. Act on the request Raised by manager
	*/
	
	@Override
	public int addAsset(Asset asset)
			throws AssetAdminException {
		return adminDao.addAsset(asset);
	}
	@Override
	public void updateAsset(Asset asset)
			throws AssetAdminException {
		adminDao.updateAsset(asset);
	}

	@Override
	public Asset searchAsset(int assetId)
			throws AssetAdminException {
		Asset asset = adminDao.searchAsset(assetId);
		return asset;
	}

	@Override
	public List<AssetAllocation> displayRequest()
			throws AssetAdminException {
		List<AssetAllocation> myAssetList = adminDao.displayRequest();
		return myAssetList;
	}
	@Override
	public void actRequestAdmin(String status, int allocationId)
			throws AssetAdminException {
		adminDao.actRequestAdmin(status, allocationId);
	}
}
