package com.capgemini.assetmgmt.dtos;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity(name="asset")
@Table(name="asset")
public class Asset implements Serializable{

	private static final long serialVersionUID = -4714810252322817416L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="assetIdGenerator")
	@SequenceGenerator(name="assetIdGenerator", sequenceName="generate_asset_id" , initialValue=1000)
	@Column
	private int assetId;
	
	@OneToMany(mappedBy="asset",cascade=CascadeType.ALL)
	private Set<AssetAllocation> assetAllocation = new HashSet<>();
	
	@Column
	@NotNull(message = "Asset Name cannot be left blank")
	@Size(min=2, max=20, message = "Asset Name should be between 2 to 20 characters")
	private String assetName;
	
	@Column
	@NotNull(message = "Asset Description cannot be left blank")
	@Size(min=2, message = "Asset Description should be greater than 2 characters")
	private String assetDes;
	
	@Column
	@NotNull(message="Asset quantity cannot be left blank")
	@Min(1)
	@Max(100)
	private int quantity;
	
	@Column
	private String status;
	
	public Asset() {
	
	}

	public Asset(int assetId, String assetName, String assetDes, int quantity,
			String status) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetDes = assetDes;
		this.quantity = quantity;
		this.status = status;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetDes() {
		return assetDes;
	}

	public void setAssetDes(String assetDes) {
		this.assetDes = assetDes;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<AssetAllocation> getAssetAllocation() {
		return assetAllocation;
	}

	public void setAssetAllocation(Set<AssetAllocation> assetAllocation) {
		this.assetAllocation = assetAllocation;
	}

	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName
				+ ", assetDes=" + assetDes + ", quantity=" + quantity
				+ ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + assetId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asset other = (Asset) obj;
		if (assetId != other.assetId)
			return false;
		return true;
	}

	public void addAssetAllocation(AssetAllocation assetAllocation){
		assetAllocation.setAsset(this);
		this.getAssetAllocation().add(assetAllocation);
	}
}
