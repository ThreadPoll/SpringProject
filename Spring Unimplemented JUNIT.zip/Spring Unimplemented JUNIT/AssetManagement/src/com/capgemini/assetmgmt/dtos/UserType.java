package com.capgemini.assetmgmt.dtos;

public enum UserType {

	admin , manager ;
	
	private UserType() {
	
	}
	
	@Override
	public String toString() {
		return super.toString();
	}
}
