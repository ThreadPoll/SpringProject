package com.capgemini.assetmgmt.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.assetmgmt.daos.AssetUserDAO;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.dtos.UserType;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/springContext.xml"})
public class LoginTest {
	
	User actual = new User();
	User expected = new User();
	boolean isCorrect = false;

	@Autowired
	AssetUserDAO assetUserDAO;
	
	@Before
	public void do_Before() throws AssetUserException{
		expected.setUserId(1001);
		expected.setUserName("Girjesh");
		expected.setUserPassword("pass@123");
		expected.setUserType(UserType.admin);
		
		isCorrect = assetUserDAO.isValidUser(expected);
	}
	
	@Test
	public void testAdminLogin(){
		Assert.assertEquals(true , isCorrect);
	}

	@Test
	public void testManagerLogin() throws AssetUserException{
		expected.setUserId(1006);
		expected.setUserName("Sneha");
		expected.setUserPassword("pass@123");
		expected.setUserType(UserType.manager);
		
		isCorrect = assetUserDAO.isValidUser(expected);
	}
}
