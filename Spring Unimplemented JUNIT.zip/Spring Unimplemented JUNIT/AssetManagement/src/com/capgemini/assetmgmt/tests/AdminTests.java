package com.capgemini.assetmgmt.tests;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.assetmgmt.daos.AssetAdminDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/WEB-INF/config/springContext.xml"})
@ActiveProfiles("oracle")
public class AdminTests {
	
	@Autowired
	AssetAdminDAO assetAdminDAO;
	
	@Test
	public void testAddAsset(){
		
	}
	
	@Test
	public void testUpdateAsset(){
		
	}
	
	@Test
	public void testDisplayRequest(){
		
	}

}
