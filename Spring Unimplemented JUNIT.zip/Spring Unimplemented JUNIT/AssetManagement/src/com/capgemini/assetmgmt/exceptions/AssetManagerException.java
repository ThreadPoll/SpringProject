package com.capgemini.assetmgmt.exceptions;

public class AssetManagerException extends Exception{

	private static final long serialVersionUID = 1L;

	public AssetManagerException() {
		super();
	}

	public AssetManagerException(String message, Throwable cause) {
		super(message, cause);
	}

	public AssetManagerException(String message) {
		super(message);
	}

	public AssetManagerException(Throwable cause) {
		super(cause);
	}

	
}
