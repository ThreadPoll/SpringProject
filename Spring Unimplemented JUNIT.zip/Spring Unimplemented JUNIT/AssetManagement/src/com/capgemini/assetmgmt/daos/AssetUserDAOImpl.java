package com.capgemini.assetmgmt.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Repository("assetUserDao")

public class AssetUserDAOImpl implements AssetUserDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	/*
	 * 1. Check the user is valid or not.
	*/	
	
	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	@Override
	public boolean isValidUser(User user) throws AssetUserException {
		int userId=user.getUserId();
		User user1;
		try {
			user1 = entityManager.find(User.class, userId);
			if(user.equals(user1)){
				myLogger.info("User is validated");
				return true;
			}
			else{
				throw new AssetUserException("Invalid Credential");
			}
		} catch (Exception e) {
			throw new AssetUserException("Invalid Credential");
		}
		
	}

}
