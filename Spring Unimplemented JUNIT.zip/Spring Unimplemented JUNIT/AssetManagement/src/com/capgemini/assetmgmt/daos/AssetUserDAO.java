package com.capgemini.assetmgmt.daos;

import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

/*Interface for abstract methods of User Dao Functions*/
public interface AssetUserDAO {
	public boolean isValidUser(User user) throws AssetUserException;
}
