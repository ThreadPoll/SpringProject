package com.capgemini.assetmgmt.daos;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetManagerException;

@Repository("managerDao")
public class AssetManagerDAOImpl implements AssetManagerDAO{

	@PersistenceContext
	EntityManager entityManager;

	/*
	 * 1. Fetch the Employee List.
	 * 2. Fetch The list of Assets.
	 * 3. Raise the request.
	 * 4. Display request Status.
	 * 5. Find Manager
	 * 6. Check whether Date is correct or not.
	*/
	
	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	
	@Override
	public List<Employee> fetchEmployeeList(int userId)
			throws AssetManagerException {
		List<Employee> employeeList;
		try {
			TypedQuery<Employee> query = entityManager.createQuery("SELECT e FROM employee e WHERE mgr="+userId,Employee.class);
			employeeList = query.getResultList();
			myLogger.info("Employee List is fetched from the table");
		} catch (Exception e) {
			throw new AssetManagerException("Can not fetch employee list");
		}
				return employeeList;
	}

	@Override
	public List<Asset> listAsset() throws AssetManagerException {
		List<Asset> assetList = null;
		try {
			TypedQuery<Asset> query = entityManager.createQuery("SELECT a FROM asset a",Asset.class);
			assetList = query.getResultList();
			myLogger.info("Assets List is fetched from the table");
		} catch (Exception e) {
			e.printStackTrace();
			throw new AssetManagerException("Can not find the asset list");
		}
		return assetList;
	}

	@Override
	public int raiseRequest(AssetAllocation assetAllocation)
			throws AssetManagerException {
		Asset asset = new Asset();
		try {
			asset = entityManager.find(Asset.class, assetAllocation.getAsset().getAssetId());
			myLogger.info("Asset is fetched from the table");
		} catch (Exception e) {
			throw new AssetManagerException("Can Not fetch Asset");
		}
		
		try {
			if(asset==null){
				throw new AssetManagerException("Asset Id does not exist");
			}
		} catch (Exception e) {
			throw new AssetManagerException(e.getMessage());
		}
		
		try {
			entityManager.persist(assetAllocation);
			myLogger.info("Asset allocation request is registered in the table");
		} catch (Exception e) {
			e.printStackTrace();
			throw new AssetManagerException("Can not raise request");
		}
		return assetAllocation.getAllocationId();
	}

	@Override
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation , int userId)
			throws AssetManagerException {
		try {
			assetAllocation = entityManager.find(AssetAllocation.class, assetAllocation.getAllocationId());
		} catch (Exception e) {
			throw new AssetManagerException("Unable to fetch request status");
		}
		
		try {
			if(assetAllocation == null){
				throw new AssetManagerException("Allocation id does not exist");
			}
		} catch (Exception e) {
			throw new AssetManagerException(e.getMessage());
		}
		
		try {
			int empNo = assetAllocation.getEmpNo();
			int mgr = findManager(empNo);
			if(mgr != userId){
				throw new AssetManagerException("This request has never been raised by you");
			}
		} catch (Exception e) {
			throw new AssetManagerException(e.getMessage());
		}
		
		myLogger.info("Request is fetched from the table");
		return assetAllocation;
	}
	
	public int findManager(int empNo){
		Employee employee = entityManager.find(Employee.class, empNo);
		return employee.getMgr();
	}

	@Override
	public boolean isValidRequestDate(AssetAllocation assetAllocation) throws AssetManagerException{
		List<AssetAllocation> requestList = null;
		Date allocationDate , releaseDate , allocDate , relDate = null;
		boolean check1 , check2 = false;
		try {
			TypedQuery<AssetAllocation> query =
					entityManager.createQuery("SELECT assetAlloc FROM assetAllocation assetAlloc WHERE assetId="+assetAllocation.getAsset().getAssetId(),AssetAllocation.class);
			requestList = query.getResultList();
		} catch (Exception e) {
			throw new AssetManagerException("Unable to fetch the list of requests");
		}
		
		try{
			for(AssetAllocation assetAllocation2 : requestList){
				allocationDate = assetAllocation.getAllocationDate();
				releaseDate = assetAllocation.getReleaseDate();
				allocDate = assetAllocation2.getAllocationDate();
				relDate = assetAllocation2.getReleaseDate();
				
				check1 = (releaseDate.before(allocDate));
				check2 = (allocationDate.after(relDate));
				
				if(check1||check2){
					return true;
				}else{
					throw new AssetManagerException("This asset is preoccupied from "+allocDate+" to "+relDate);
				}
			}
		}catch(Exception e1){
			throw new AssetManagerException(e1.getMessage());
		}
		return false;
	}
	
}
