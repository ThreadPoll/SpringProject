package com.capgemini.assetmgmt.daos;

import java.util.List;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetManagerException;

/*Interface for abstract methods of Manager Dao Functions*/
public interface AssetManagerDAO {

	public List<Asset> listAsset() throws AssetManagerException;
	public int raiseRequest(AssetAllocation assetAllocation) throws AssetManagerException;
	public List<Employee> fetchEmployeeList(int userId) throws AssetManagerException;
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation, int userId) throws AssetManagerException;
	public boolean isValidRequestDate(AssetAllocation assetAllocation) throws AssetManagerException;
}
