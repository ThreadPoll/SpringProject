	alert("in script");
	var app = angular.module("myApp", []);
	app.controller("myCtrl", function($scope , $http) {
		refreshData();

		function refreshData(){
			alert("function called");
			$http({
				method: 'GET',
				url:'http://localhost:8081/SpringWithAngularJs/rest/countries.json'
					}).success(function(data)
						{
					
						$scope.posts = data;
					
						});
		}
		$scope.form = {
				countryName : "pp",
				population : "1000"
					};
		$scope.add=function(){
			$http({
				method: 'POST',
				url:'http://localhost:8081/SpringWithAngularJs/rest/countries/create/'+$scope.form.countryName+'/'+$scope.form.population
				}).success(function(data){
					alert("Country Added");
					refreshData();
					});
			}
		$scope.remove=function(data){
			$http({
				method: 'DELETE',
				url:'http://localhost:8081/SpringWithAngularJs/rest/countries/delete/'+data
				}).success(function(data){
					alert('Country Deleted');
					refreshData();
					});
		}
	});