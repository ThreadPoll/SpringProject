package com.cg.springwithangularjs.daos;

import java.util.List;

import com.cg.springwithangularjs.dtos.Country;
import com.cg.springwithangularjs.exceptions.CountryException;

public interface CountryDAO {

	public Country addCountry(Country country) throws CountryException;

	public List<Country> getAllCountries() throws CountryException;

	public void deleteCountry(int id) throws CountryException;

}
