package com.cg.springwithangularjs.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.springwithangularjs.dtos.Country;
import com.cg.springwithangularjs.exceptions.CountryException;

@Repository("countryDAO")
public class CountryDAOImpl implements CountryDAO{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Country addCountry(Country country) throws CountryException {
		entityManager.persist(country);
		return country;
	}

	@Override
	public List<Country> getAllCountries() throws CountryException {
		TypedQuery<Country> query = entityManager.createQuery("SELECT c FROM country c", Country.class);
		return query.getResultList();
	}

	@Override
	public void deleteCountry(int id) throws CountryException {
		Country country = getAllCountries().get(id);
		System.out.println("country is "+country);
		entityManager.remove(country);
	}
	
}
