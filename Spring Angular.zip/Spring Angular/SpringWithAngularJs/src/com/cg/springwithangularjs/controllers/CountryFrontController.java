package com.cg.springwithangularjs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springwithangularjs.dtos.Country;
import com.cg.springwithangularjs.exceptions.CountryException;
import com.cg.springwithangularjs.services.CountryService;

@RestController
public class CountryFrontController {
	@Autowired
	CountryService countryService;
	
	@RequestMapping(value="/countries",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Country> getallCountries(Model model){
		System.out.println("in function");
		try {
			return countryService.getAllCountries();
		} catch (CountryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value="/countries/create/{name}/{popu}",method=RequestMethod.POST,headers="Accept=application/json")
	public List<Country> addCountry(@PathVariable String name , @PathVariable String popu){
		Country country = new Country();
		country.setCountryName(name);
		country.setPopulation(popu);
		
		try {
			countryService.addCountry(country);
			return countryService.getAllCountries();
		} catch (CountryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	@RequestMapping(value="/countries/delete/{id}",method=RequestMethod.DELETE,headers="Accept=application/json")
	public List<Country> deleteCountry(@PathVariable int id){
		try {
			System.out.println("id is"+id);
			countryService.delete(id);
			return countryService.getAllCountries();
		} catch (CountryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
