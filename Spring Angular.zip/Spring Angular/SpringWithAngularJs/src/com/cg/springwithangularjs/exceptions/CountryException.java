package com.cg.springwithangularjs.exceptions;

public class CountryException extends Exception {

	public CountryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CountryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CountryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CountryException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
