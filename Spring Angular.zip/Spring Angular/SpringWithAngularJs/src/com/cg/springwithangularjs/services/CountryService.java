package com.cg.springwithangularjs.services;

import java.util.List;

import com.cg.springwithangularjs.dtos.Country;
import com.cg.springwithangularjs.exceptions.CountryException;

public interface CountryService {

	public List<Country> getAllCountries() throws CountryException;
	public Country addCountry(Country country) throws CountryException;
	public void delete(int id) throws CountryException;
}
