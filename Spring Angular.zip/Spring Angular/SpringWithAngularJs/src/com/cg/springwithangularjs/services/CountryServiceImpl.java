package com.cg.springwithangularjs.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springwithangularjs.daos.CountryDAO;
import com.cg.springwithangularjs.dtos.Country;
import com.cg.springwithangularjs.exceptions.CountryException;

@Service("countryService")
@Transactional
public class CountryServiceImpl implements CountryService{

	@Resource(name="countryDAO")
	CountryDAO countryDAO;

	@Override
	public Country addCountry(Country country) throws CountryException {
		return countryDAO.addCountry(country);
	}

	@Override
	public List<Country> getAllCountries() throws CountryException {
		return countryDAO.getAllCountries();
	}

	@Override
	public void delete(int id) throws CountryException {
		countryDAO.deleteCountry(id);
	}
}
