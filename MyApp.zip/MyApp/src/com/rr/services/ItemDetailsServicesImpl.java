package com.rr.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rr.daos.ItemDetailsDAO;
import com.rr.dtos.ItemDetails;
import com.rr.exceptions.ItemDetailsException;

@Service("itemDetailsServices")
@Transactional
public class ItemDetailsServicesImpl implements ItemDetailsServices{

	@Resource(name="itemDetailsDao")
	ItemDetailsDAO detailsDao;
	
	@Override
	public int addItemDetails(ItemDetails itemDetails)
			throws ItemDetailsException {
		return detailsDao.addItemDetails(itemDetails);
	}

	@Override
	public List<ItemDetails> getAllDetails() throws ItemDetailsException {
		return detailsDao.getAllDetails();
	}
}
