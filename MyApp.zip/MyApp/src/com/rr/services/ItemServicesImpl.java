package com.rr.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rr.daos.ItemDAO;
import com.rr.dtos.Customer;
import com.rr.dtos.Items;
import com.rr.exceptions.ItemException;

@Service("itemServices")
@Transactional
public class ItemServicesImpl implements ItemServices{

	@Resource(name="itemDao")
	ItemDAO appDao;
	
	@Override
	public void getAmount() throws ItemException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int addItem(Items items) throws ItemException {
		return appDao.addItem(items);
	}

	@Override
	public Items fetchItem(int id) throws ItemException {
		return appDao.fetchItem(id);
	}

	@Override
	public void updateItem(Items items) throws ItemException {
		appDao.updateItem(items);
	}

	@Override
	public double getBill(double weight, double mCharges, double rate)
			throws ItemException {
		double price = (rate/10+mCharges)*weight;
				return price;
	}

}
