package com.rr.services;

import java.util.List;

import com.rr.dtos.ItemDetails;
import com.rr.exceptions.ItemDetailsException;

public interface ItemDetailsServices {

	public int addItemDetails(ItemDetails itemDetails) throws ItemDetailsException;
	public List<ItemDetails> getAllDetails() throws ItemDetailsException;
}
