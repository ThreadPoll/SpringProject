package com.rr.services;

import com.rr.dtos.Customer;
import com.rr.dtos.Items;
import com.rr.exceptions.ItemException;

public interface ItemServices {

	public void getAmount()throws ItemException;
	public int addItem(Items items) throws ItemException;
	public Items fetchItem(int id) throws ItemException;
	public void updateItem(Items items) throws ItemException;
	public double getBill(double weight, double mCharges, double rate) throws ItemException;
}
