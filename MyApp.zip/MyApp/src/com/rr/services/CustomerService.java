package com.rr.services;

import com.rr.dtos.Customer;
import com.rr.exceptions.CustomerException;

public interface CustomerService {

	public Customer addCustomer(Customer customer) throws CustomerException;
	public Customer fetchCustomer(int billId) throws CustomerException;
	public Customer updateCustomer(Customer customer) throws CustomerException;
}
