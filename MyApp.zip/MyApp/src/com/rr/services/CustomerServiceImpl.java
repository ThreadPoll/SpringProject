package com.rr.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rr.daos.CustomerDAO;
import com.rr.dtos.Customer;
import com.rr.exceptions.CustomerException;

@Service("customerServices")
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Resource(name="customerDao")
	CustomerDAO customerDao;
	
	@Override
	public Customer addCustomer(Customer customer) throws CustomerException {
		return customerDao.addCustomer(customer);
	}

	@Override
	public Customer fetchCustomer(int billId) throws CustomerException {
		return customerDao.fetchCustomer(billId);
	}

	@Override
	public Customer updateCustomer(Customer customer) throws CustomerException {
		return customerDao.updateCustomer(customer);
	}

}
