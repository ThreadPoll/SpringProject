package com.rr.dtos;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity(name="customer")
@Table(name="customer4")
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO , generator="billIdGenerator")
	@SequenceGenerator(name="billIdGenerator" , sequenceName="generate_bill_id" , initialValue=10 , allocationSize=10)
	@Column
	private int billId;
	
	@Column
	private String cName;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address")
	private Address address;
	
	@OneToMany(fetch = FetchType.EAGER , mappedBy="customer" , targetEntity=Items.class)
	private List<Items> items;
	
	@Column
	private Date billingDate;
	
	@Column
	private double price;
	
	@Column(nullable=true)
	private Double rate;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int billId, String cName, Address address,
			List<Items> items, Date billingDate, double price, double rate) {
		super();
		this.billId = billId;
		this.cName = cName;
		this.address = address;
		this.items = items;
		this.billingDate = billingDate;
		this.price = price;
		this.rate = rate;
	}
	
	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	public Date getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(Date billingDate) {
		this.billingDate = billingDate;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Customer [billId=" + billId + ", cName=" + cName + ", address="
				+ address + ", items=" + items + ", billingDate=" + billingDate
				+ ", price=" + price + ", rate=" + rate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + billId;
		result = prime * result
				+ ((billingDate == null) ? 0 : billingDate.hashCode());
		result = prime * result + ((cName == null) ? 0 : cName.hashCode());
		result = prime * result + ((items == null) ? 0 : items.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (billId != other.billId)
			return false;
		if (billingDate == null) {
			if (other.billingDate != null)
				return false;
		} else if (!billingDate.equals(other.billingDate))
			return false;
		if (cName == null) {
			if (other.cName != null)
				return false;
		} else if (!cName.equals(other.cName))
			return false;
		if (items == null) {
			if (other.items != null)
				return false;
		} else if (!items.equals(other.items))
			return false;
		return true;
	}

	public void addItems(Items items) {
		items.setCustomer(this);			//this will avoid nested cascade
		this.getItems().add(items);
	}
	
}
