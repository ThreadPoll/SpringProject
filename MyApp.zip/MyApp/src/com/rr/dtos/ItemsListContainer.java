package com.rr.dtos;

import java.util.List;

public class ItemsListContainer {

	private List<Items> itemsList;
	
	public ItemsListContainer() {
		// TODO Auto-generated constructor stub
	}

	public ItemsListContainer(List<Items> itemsList) {
		super();
		this.itemsList = itemsList;
	}

	public List<Items> getItemsList() {
		return itemsList;
	}

	public void setItemsList(List<Items> itemsList) {
		this.itemsList = itemsList;
	}
	
	
}
