package com.rr.dtos;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="items")
@Table(name="items5")
public class Items implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int id;
	
	private double weight;
	
	private ItemDetails itemDetails;
	
	private Customer customer;
	
	public Items() {
		super();
	}

	public Items(int id, double weight, ItemDetails itemDetails,
			Customer customer) {
		super();
		this.id = id;
		this.weight = weight;
		this.itemDetails = itemDetails;
		this.customer = customer;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO , generator="itemIdGenerator")
	@SequenceGenerator(name="itemIdGenerator" , sequenceName="generate_item_id")
	@Column
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column
	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	@ManyToOne
	@JoinColumn(name="itemNo")
	public ItemDetails getItemDetails() {
		return itemDetails;
	}

	public void setItemDetails(ItemDetails itemDetails) {
		this.itemDetails = itemDetails;
	}

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer")
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Items [id=" + id + ", weight=" + weight + ", itemDetails="
				+ itemDetails + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + id;
		result = prime * result
				+ ((itemDetails == null) ? 0 : itemDetails.hashCode());
		long temp;
		temp = Double.doubleToLongBits(weight);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Items other = (Items) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (id != other.id)
			return false;
		if (itemDetails == null) {
			if (other.itemDetails != null)
				return false;
		} else if (!itemDetails.equals(other.itemDetails))
			return false;
		if (Double.doubleToLongBits(weight) != Double
				.doubleToLongBits(other.weight))
			return false;
		return true;
	}
	
}
