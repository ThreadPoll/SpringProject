package com.rr.dtos;

public enum Category {

	male , female , both , child;
	
	private Category() {

	}
	
	@Override
	public String toString() {
		return super.toString();
	}
}
