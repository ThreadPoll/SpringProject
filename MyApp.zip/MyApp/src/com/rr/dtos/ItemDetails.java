package com.rr.dtos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="itemDetails")
@Table(name="itemDetails2")
public class ItemDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO , generator="categoryIdGenerator")
	@SequenceGenerator(name="categoryIdGenerator" , sequenceName="generate_category_id" , initialValue=10 , allocationSize=10)
	@Column
	private int id;
	
	@Column
	private String name;
	
	@Column
	@Enumerated(EnumType.STRING)
	private Category category;
	
	@OneToMany(mappedBy="itemDetails" , cascade=CascadeType.ALL)
	private Set<Items> items = new HashSet<>();
	
	public ItemDetails() {
		super();
	}

	public ItemDetails(int id, String name, Category category, Set<Items> items) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.items = items;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<Items> getItems() {
		return items;
	}

	public void setItems(Set<Items> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "ItemDetails [id=" + id + ", name=" + name + ", category="
				+ category + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemDetails other = (ItemDetails) obj;
		if (category != other.category)
			return false;
		if (id != other.id)
			return false;
		if (items == null) {
			if (other.items != null)
				return false;
		} else if (!items.equals(other.items))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
