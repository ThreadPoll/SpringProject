package com.rr.exceptions;

public class ItemDetailsException extends Exception {

	private static final long serialVersionUID = 1L;

	public ItemDetailsException() {
		super();
	}

	public ItemDetailsException(String message, Throwable cause) {
		super(message, cause);
	}

	public ItemDetailsException(String message) {
		super(message);
	}

	public ItemDetailsException(Throwable cause) {
		super(cause);
	}
}
