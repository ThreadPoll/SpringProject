package com.rr.exceptions;

public class CustomerException extends Exception {

	private static final long serialVersionUID = 1L;

	public CustomerException() {
		super();
	}

	public CustomerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public CustomerException(String arg0) {
		super(arg0);
	}

	public CustomerException(Throwable arg0) {
		super(arg0);
	}

}
