package com.rr.exceptions;

public class ItemException extends Exception {

	private static final long serialVersionUID = 1L;

	public ItemException() {
		super();
	}

	public ItemException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ItemException(String arg0) {
		super(arg0);
	}

	public ItemException(Throwable arg0) {
		super(arg0);
	}

}
