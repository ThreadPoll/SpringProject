package com.rr.exceptions;

public class MyAppException extends Exception {

	private static final long serialVersionUID = 1L;

	public MyAppException() {
		super();
	}

	public MyAppException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public MyAppException(String arg0) {
		super(arg0);
	}

	public MyAppException(Throwable arg0) {
		super(arg0);
	}
	
}
