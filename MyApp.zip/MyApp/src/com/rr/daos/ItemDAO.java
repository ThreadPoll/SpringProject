package com.rr.daos;

import com.rr.dtos.Customer;
import com.rr.dtos.Items;
import com.rr.exceptions.ItemException;

public interface ItemDAO {
	public void getAmount()throws ItemException;
	public int addItem(Items items) throws ItemException;
	public Items fetchItem(int id) throws ItemException;
	public void updateItem(Items items) throws ItemException;
}
