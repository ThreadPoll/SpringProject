package com.rr.daos;

import com.rr.dtos.Customer;
import com.rr.exceptions.CustomerException;

public interface CustomerDAO {

	public Customer addCustomer(Customer customer) throws CustomerException;
	public Customer fetchCustomer(int billId) throws CustomerException;
	public Customer updateCustomer(Customer customer) throws CustomerException;
}
