package com.rr.daos;

import java.util.List;

import com.rr.dtos.ItemDetails;
import com.rr.exceptions.ItemDetailsException;

public interface ItemDetailsDAO {

	public int addItemDetails(ItemDetails itemDetails) throws ItemDetailsException;
	public List<ItemDetails> getAllDetails() throws ItemDetailsException;	
}
