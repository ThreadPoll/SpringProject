package com.rr.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.rr.dtos.Customer;
import com.rr.dtos.Items;
import com.rr.exceptions.ItemException;

@Repository("itemDao")
public class ItemDAOImpl implements ItemDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void getAmount() throws ItemException{
		// TODO Auto-generated method stub
		
	}

	@Override
	public int addItem(Items items) throws ItemException {
		entityManager.persist(items);
		return items.getId();
	}

	@Override
	public Items fetchItem(int id) throws ItemException {
		Items items = entityManager.find(Items.class, id);
		return items;
	}

	@Override
	public void updateItem(Items items) throws ItemException {
		entityManager.merge(items);
	}

}
