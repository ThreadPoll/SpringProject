package com.rr.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.rr.dtos.Customer;
import com.rr.exceptions.CustomerException;

@Repository("customerDao")
public class CustomerDAOImpl implements CustomerDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Customer addCustomer(Customer customer) throws CustomerException {
		entityManager.persist(customer);
		return customer;
	}

	@Override
	public Customer fetchCustomer(int billId) throws CustomerException {
		Customer customer = entityManager.find(Customer.class, billId);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) throws CustomerException {
		customer = entityManager.merge(customer);
		return customer;
	}

}
