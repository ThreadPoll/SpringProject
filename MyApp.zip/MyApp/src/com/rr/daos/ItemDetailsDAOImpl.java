package com.rr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.rr.dtos.ItemDetails;
import com.rr.exceptions.ItemDetailsException;

@Repository("itemDetailsDao")
public class ItemDetailsDAOImpl implements ItemDetailsDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int addItemDetails(ItemDetails itemDetails)
			throws ItemDetailsException {
		entityManager.persist(itemDetails);
		return itemDetails.getId();
	}

	@Override
	public List<ItemDetails> getAllDetails() throws ItemDetailsException {
		TypedQuery<ItemDetails> query = entityManager.createQuery("SELECT details FROM itemDetails details",ItemDetails.class);
		List<ItemDetails> detailsList = query.getResultList();
		return detailsList;
	}
}
