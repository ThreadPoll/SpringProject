package com.rr.controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.rr.dtos.Address;
import com.rr.dtos.Customer;
import com.rr.dtos.ItemDetails;
import com.rr.dtos.Items;
import com.rr.exceptions.CustomerException;
import com.rr.exceptions.ItemDetailsException;
import com.rr.exceptions.ItemException;
import com.rr.services.CustomerService;
import com.rr.services.ItemDetailsServices;
import com.rr.services.ItemServices;

@Controller
public class MyAppFrontController {
	
	@Resource(name="itemServices")
	ItemServices appServices;

	@Resource(name="itemDetailsServices")
	ItemDetailsServices detailsServices;
	
	@Resource(name="customerServices")
	CustomerService customerService;
	
	@RequestMapping("/index")					
	public String returnHomePage(){
		return "index";
	}
	
	@RequestMapping("/getMenu")
	public String getMenu(@RequestParam("rate") double rate , HttpServletRequest request){
        ServletContext sc = request.getSession().getServletContext();
        WebApplicationContext appContext = WebApplicationContextUtils.getWebApplicationContext(sc);
        sc.setAttribute("rate", rate);
		return "menuPage";
	}
	
	@RequestMapping("/getAddItemForm")
	public String getAddItemForm(Model model){
		Items items = new Items();
		model.addAttribute("items", items);
		return "addItem";
	}
	
	@RequestMapping("/addItem")
	public String addItem(@ModelAttribute Items items, Model model){
		try {
			int id = appServices.addItem(items);
			model.addAttribute("id",id);
			return "postAddItem";
		} catch (ItemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping("/getUpdateItemForm")
	public String getUpdateItemForm(Model model){
		Items items = new Items();
		model.addAttribute("items", items);
		return "getUpdateItemForm";
	}
	
	@RequestMapping("/fetchItem")
	public String fetchItem(@ModelAttribute Items items , Model model){
		try {
			items = appServices.fetchItem(items.getId());
		} catch (ItemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("items", items);
		return "getUpdateItemForm";
	}
	
	@RequestMapping("/updateItem")
	public String updateItem(@ModelAttribute Items items , Model model){
		try {
			appServices.updateItem(items);
		} catch (ItemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "menuPage";
		
	}
	
	@RequestMapping("/calculateBill")
	public String calculateBill(){
		return "getOptions";
	}
	
	@RequestMapping("/options")
	public String options(@RequestParam("choice") String choice , Model model){
		Items items = new Items();
		model.addAttribute("items",items);
		if(choice.equals("byId")){
			return "getBillId";
		}else if (choice.equals("byWeight")) {
			return "getBillWeight";
		}
		return null;
	}
	
	@RequestMapping("/getBill")
	public String getBill(@RequestParam("makingCharges") double mCharges , @ModelAttribute Items items , Model model , HttpServletRequest request){
		if(items.getId()!=0){
			try {
				items = appServices.fetchItem(items.getId());
				System.out.println("items is "+items);
			} catch (ItemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		double rate = (double) request.getSession().getServletContext().getAttribute("rate");
		try {
			double price = appServices.getBill(items.getWeight() , mCharges , rate);
			model.addAttribute("price", price);
		} catch (ItemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "billDisplay";
	}
	
	@RequestMapping("/getItemDetailsForm")
	public String getItemDetailsForm(Model model){
		ItemDetails itemDetails = new ItemDetails();
		model.addAttribute("itemDetails", itemDetails);
		return "addItemDetails";
	}
	
	@RequestMapping("/addItemDetails")
	public String addItemDetails(@ModelAttribute ItemDetails itemDetails , Model model){
		try {
			int detailId = detailsServices.addItemDetails(itemDetails);
			model.addAttribute("detailId", detailId);
		} catch (ItemDetailsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "postDetailsAdd";
	}
	
	@RequestMapping("/getAllDetails")
	public String getAllDetails(@ModelAttribute Items items , Model model){
		try {
			List<ItemDetails> detailsList = detailsServices.getAllDetails();
			model.addAttribute("detailsList", detailsList);
			model.addAttribute("items" , items);
		} catch (ItemDetailsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "addItem";
	}
	
	@RequestMapping("/printBill")
	public String printBill(Model model , HttpServletRequest request){
		Customer customer = new Customer();
		List<Items> itemsList = new ArrayList<Items>();
		Items items = new Items();
		itemsList.add(items);
		model.addAttribute("customer", customer);
		request.setAttribute("itemList", itemsList);
		request.setAttribute("index", itemsList.size());
		System.out.println("size is "+itemsList.size());
		return "customerForm";
	}
	
	@RequestMapping("/getRows")
	public String getRows(Model model , HttpServletRequest request , @ModelAttribute Customer customer ,@RequestParam("index") int index /*,@RequestParam(required=false , value="itemsList") List<Items> itemsList*/){
		System.out.println("index is "+index);
		Items items = new Items();
		List<Items> itemsList = new ArrayList<Items>();
		for(int i=0 ; i<index ; i++){
			itemsList.add(items);
		}		
		model.addAttribute("customer", customer);
		request.setAttribute("itemList", itemsList);
		request.setAttribute("index", itemsList.size());
		return "customerForm";
	}
	
	@RequestMapping("/addCustomer")
	public String addCustomer(@ModelAttribute Customer customer , @RequestParam("makingCharges") Double mCharges/* ,@RequestParam("itemList") List<Items> itemList*/, Model model , HttpServletRequest request){
		/*customer.setItems(itemList);*/
		Date today = new Date(Calendar.getInstance().getTime().getTime());
		double rate = (double) request.getSession().getServletContext().getAttribute("rate");
		customer.setRate(rate);
		System.out.println("ItemList is "+customer.getItems());
		List<Items> list = new ArrayList<Items>();
		double price = 0.0;
		System.out.println("date is "+today);
		customer.setBillingDate(today);
		System.out.println("customer1 is "+customer);
		try {
			for(Items items : customer.getItems()){
				System.out.println("items is "+items);
				items = appServices.fetchItem(items.getId());
				System.out.println("items2 is "+items);
				list.add(items);
				System.out.println("list is"+list);
			}

			customer.getItems().clear();
			for(Items items : list){
					customer.getItems().add(items);
			}
			System.out.println("hello");
			customer = customerService.addCustomer(customer);
			System.out.println("hello again");
			System.out.println("customer is "+customer);
			for(Items items : customer.getItems()){
				System.out.println("item inside is "+items);
				items.setCustomer(customer);
				System.out.println("item inside2 is "+items);
				appServices.updateItem(items);
			}
			System.out.println("item 3 is "+customer.getItems());
			customer = customerService.fetchCustomer(customer.getBillId());
			System.out.println("customer is "+customer);
			for (Items items : customer.getItems()) {
				price = (appServices.getBill(items.getWeight(), mCharges, rate))+price;
			}
			customer.setPrice(price);
			customer = customerService.updateCustomer(customer);
			model.addAttribute("customer", customer);
		} catch (CustomerException | ItemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "displayBill";
	}
	
	@RequestMapping("/getBillDetailsForm")
	public String getBillDetailsForm(Model model){
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "getBillDetailsForm";
	}
	
	@RequestMapping("/getBillDetails")
	public String getBillDetails(Model model , @ModelAttribute Customer customer){
		try {
			customer = customerService.fetchCustomer(customer.getBillId());
			System.out.println("Customer is "+customer);
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("customer", customer);
		return "billDetails";
	}
}
