package com.capgemini.assetmgmt.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetAuthenticationException;

@Repository("assetAuthenticationDao")
public class AssetAuthenticationDAOImpl implements AssetAuthenticationDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public boolean isValidUser(User user) throws AssetAuthenticationException {
		int userId=user.getUserId();
		User user1;
		try {
			user1 = entityManager.find(User.class, userId);
			if(user.equals(user1)){
				return true;
			}
			else{
				throw new AssetAuthenticationException("Invalid Credential");
			}
		} catch (Exception e) {
			throw new AssetAuthenticationException("Invalid Credential");
		}
		
	}

}
