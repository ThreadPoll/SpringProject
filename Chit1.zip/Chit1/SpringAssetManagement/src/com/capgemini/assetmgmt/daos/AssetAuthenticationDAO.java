package com.capgemini.assetmgmt.daos;

import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetAuthenticationException;

public interface AssetAuthenticationDAO {

	public boolean isValidUser(User user) throws AssetAuthenticationException;
}
