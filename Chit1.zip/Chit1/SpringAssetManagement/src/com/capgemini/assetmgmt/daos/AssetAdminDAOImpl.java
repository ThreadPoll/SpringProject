package com.capgemini.assetmgmt.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Status;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Repository("adminDao")
public class AssetAdminDAOImpl implements AssetAdminDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int addAsset(Asset asset) throws AssetAdminException {
		try {
			entityManager.persist(asset);
		} catch (Exception e) {
			throw new AssetAdminException("CanNot perform add function");
		}
		return asset.getAssetId();
	}

	@Override
	public void updateAsset(Asset asset) throws AssetAdminException {
		try {
			entityManager.merge(asset);
		} catch (Exception e) {
			throw new AssetAdminException("Can Not Update Asset");
		}
	}

	@Override
	public Asset searchAsset(int assetId) throws AssetAdminException {
		Asset asset = null;
		try {
			asset = entityManager.find(Asset.class, assetId);
		} catch (Exception e) {
			throw new AssetAdminException("Can Not fetch the asset");
		}
		
		try {
			if(asset==null){
				throw new AssetAdminException("Asset ID Not found");
			}
		} catch (Exception e) {
			throw new AssetAdminException(e.getMessage());
		}
		
		return asset;
	}

	@Override
	public List<AssetAllocation> displayRequest() throws AssetAdminException {
		List<AssetAllocation> requestList = null;
		try {
			TypedQuery<AssetAllocation> query = entityManager.createQuery("SELECT a FROM assetAllocation a",AssetAllocation.class);
			requestList = query.getResultList();
		} catch (Exception e) {
			throw new AssetAdminException("Unable to fetch requestList");
		}
		return requestList;
	}

	@Override
	public void actRequestAdmin(String act, int allocationId)
			throws AssetAdminException {
		AssetAllocation assetAllocation = null;
		
		try {
			assetAllocation = entityManager.find(AssetAllocation.class, allocationId);
			assetAllocation.setStatus(Status.valueOf(act));
			assetAllocation = entityManager.merge(assetAllocation);
		} catch (Exception e) {
			throw new AssetAdminException("Can Not fetch the asset");
		}
		
	}
	
	public boolean isValidId(String id) throws AssetAdminException{
		
		/*String queryFour = "select assetid from asset where assetid=?";
		int flag = 0;
		
		try(Connection con = DbUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement(queryFour);
			pstm.setString(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next()){
				flag = 1;
			}
		} catch (Exception e) {
			throw new AssetAdminException("Id Does Not Exist");
		}
		
		if(flag==0){
			return false;
		}
		else{
			return true;
		}
		*/
		return false;
	}
	
	public void deleteRequestAdmin(int allocationId) throws AssetAdminException{
	/*	String query = "DELETE FROM asset_allocation WHERE allocationid=?";
		try(Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setInt(1, allocationId);
			pstm.executeUpdate();
		}catch (Exception e) {
			throw new AssetAdminException("Problem in deleting the Allocation Request");
		}*/
	}

	public static int generateAssetId() throws AssetUserException{
		/*String query = "SELECT generate_asset_id.nextval FROM DUAL";
		int id = 0;
		try(Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while(res.next()){
			 id = res.getInt("nextval");
			}
		}
		catch (Exception e) {
			throw new AssetUserException("Unable to generate Asset ID");
		}
		return id;*/
		return 0;
	}

	
}