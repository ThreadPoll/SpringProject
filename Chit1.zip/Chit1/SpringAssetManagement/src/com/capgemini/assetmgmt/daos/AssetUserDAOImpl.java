package com.capgemini.assetmgmt.daos;

import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Repository("userDao")
public class AssetUserDAOImpl implements AssetUserDAO{
	
	@PersistenceContext
	EntityManager entityManager;

	public boolean isValidAllocationId(String id) throws AssetAdminException{

		/*String queryFour = "select allocationId from asset_Allocation where allocationId=?";
		int flag = 0;

		try(Connection con = DbUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement(queryFour);
			pstm.setString(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next()){
				flag = 1;
			}
		} catch (Exception e) {
			throw new AssetAdminException("Id Does Not Exist");
		}

		if(flag==0){
			return false;
		}
		else{
			return true;
		}
*/	return false;
	}

	@Override
	public List<Employee> fetchEmployeeList(int userId)
			throws AssetUserException {
		List<Employee> employeeList;
		try {
			TypedQuery<Employee> query = entityManager.createQuery("SELECT e FROM employee e WHERE MGR="+userId,Employee.class);
			employeeList = query.getResultList();
		} catch (Exception e) {
			throw new AssetUserException("Can not fetch employee list");
		}
				return employeeList;
	}


	public boolean checkAvailablity(AssetAllocation assetAllocation)
			throws AssetUserException {

	/*	String query = "SELECT allocation_date , release_date from asset_allocation where assetId = ?";
		int flag = 1;

		Date allocationDate = null;

		Date releaseDate = null;


		boolean check1, check2, check3, check4 = false;

		try (Connection con = DbUtil.getConnection()) {

			PreparedStatement pstm = con.prepareStatement(query);

			pstm.setInt(1, assetAllocation.getAssetId());

			ResultSet res = pstm.executeQuery();

			while (res.next()) {

				flag = 0;
				allocationDate = res.getDate(1);

				releaseDate = res.getDate(2);

				check1 = allocationDate.before(assetAllocation
						.getAllocationDate());

				check2 = releaseDate.before(assetAllocation.getReleaseDate());

				check3 = allocationDate.after(assetAllocation
						.getAllocationDate());

				check4 = releaseDate.after(assetAllocation.getReleaseDate());

				if (!((check1 && check2) || (check3 && check4))) {
					throw new AssetUserException("Asset is preoccupied from "+allocationDate+" to "+releaseDate);
				}else{
					flag = 1;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new AssetUserException("Can Not Compare Date");
		}
		if(flag==1){
			return true;
		}else{
			return false;
		}*/
		return true;
	}

	public static int generateAllocId() throws AssetUserException{
		/*String query = "SELECT generate_allocation_id.nextval FROM DUAL";
		int id = 0;
		try(Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				id = res.getInt("nextval");
			}
		}
		catch (Exception e) {
			throw new AssetUserException("Unable to generate Allocation ID");
		}
		return id;*/
		return 0 ;
	}

	public int getManager(int id) throws AssetUserException{
		/*String query = "SELECT mgr FROM employee where empNo=?";
		int mgr = 0;
		try(Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setInt(1, id);
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				mgr = res.getInt(1);
			}
		}catch (Exception e) {
			throw new AssetUserException("Can Not find manager for this employee");
		}
		return mgr;*/
		return id;
	}

	@Override
	public List<Asset> listAsset() throws AssetUserException {
		List<Asset> assetList = null;
		try {
			TypedQuery<Asset> query = entityManager.createQuery("SELECT a FROM asset a",Asset.class);
			assetList = query.getResultList();
		} catch (Exception e) {
			throw new AssetUserException("Can not find the asset list");
		}
		return assetList;
	}

	@Override
	public int raiseRequest(AssetAllocation assetAllocation)
			throws AssetUserException {
		Asset asset = new Asset();
		try {
			asset = entityManager.find(Asset.class, assetAllocation.getAsset().getAssetId());
		} catch (Exception e) {
			throw new AssetUserException("Can Not fetch Asset");
		}
		
		try {
			if(asset==null){
				throw new AssetUserException("Asset Id does not exist");
			}
		} catch (Exception e) {
			throw new AssetUserException(e.getMessage());
		}
		
		try {
			entityManager.persist(assetAllocation);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AssetUserException("Can not raise request");
		}
		return assetAllocation.getAllocationId();
	}

	@Override
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation , int userId)
			throws AssetUserException {
		try {
			assetAllocation = entityManager.find(AssetAllocation.class, assetAllocation.getAllocationId());
		} catch (Exception e) {
			throw new AssetUserException("Unable to fetch request status");
		}
		
		try {
			if(assetAllocation == null){
				throw new AssetUserException("Allocation id does not exist");
			}
		} catch (Exception e) {
			throw new AssetUserException(e.getMessage());
		}
		
		try {
			int empNo = assetAllocation.getEmpNo();
			int mgr = findManager(empNo);
			if(mgr != userId){
				throw new AssetUserException("This request has never been raised by you");
			}
		} catch (Exception e) {
			throw new AssetUserException(e.getMessage());
		}
		
		
		return assetAllocation;
	}
	
	public int findManager(int empNo){
		Employee employee = entityManager.find(Employee.class, empNo);
		return employee.getMgr();
	}
}
