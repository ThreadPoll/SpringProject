package com.capgemini.assetmgmt.daos;

import java.util.List;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;

public interface AssetAdminDAO {
	public int addAsset(Asset asset) throws AssetAdminException;
	public void updateAsset(Asset asset) throws AssetAdminException;
	public Asset searchAsset(int assetId) throws AssetAdminException;
	public List<AssetAllocation> displayRequest() throws AssetAdminException;
	public void actRequestAdmin(String act , int assetId) throws AssetAdminException;
}
