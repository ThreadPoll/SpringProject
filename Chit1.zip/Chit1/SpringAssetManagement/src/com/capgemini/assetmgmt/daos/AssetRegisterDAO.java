package com.capgemini.assetmgmt.daos;

import java.sql.SQLException;

import org.springframework.ui.Model;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetException;
import com.capgemini.assetmgmt.exceptions.RegisterException;

public interface AssetRegisterDAO 
{
	/*public boolean validateUser(User user);*/
	/*public int addUser(User user) throws SQLException, RegisterException;
	public boolean validateEmployee(Employee emp);
	boolean validateUser(User user, Model model);
	public boolean isValidUser(User user);*/
	boolean searchUser(User user);
	boolean searchEmployee(Employee emp);
	public int addUser(User user) throws SQLException, RegisterException;
	boolean searchEmployeeNotNull(Employee emp);
}
