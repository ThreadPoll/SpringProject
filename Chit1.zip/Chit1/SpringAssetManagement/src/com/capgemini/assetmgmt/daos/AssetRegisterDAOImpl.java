package com.capgemini.assetmgmt.daos;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;
import com.capgemini.assetmgmt.exceptions.AssetAuthenticationException;
import com.capgemini.assetmgmt.exceptions.AssetException;
import com.capgemini.assetmgmt.exceptions.RegisterException;

@Repository("registerDao")
public class AssetRegisterDAOImpl implements AssetRegisterDAO {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean searchUser(User user) {
	
		User user1;
		user1 = entityManager.find(User.class, user.getUserId());
		if (user1 == null)
		{
		return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean searchEmployee(Employee emp) {
		Employee emp1;
		emp1 = entityManager.find(Employee.class, emp.getEmpNo());
		//if (emp1 == null && emp.getMgr() == emp.getEmpNo())
		if (emp.getEmpNo()== emp.getMgr() || (emp.getMgr() == 0))
		{
		return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public int addUser(User user) throws SQLException, RegisterException {
		try {
			
			entityManager.persist(user);
		} catch (Exception e) {
			try {
				throw new RegisterException("CanNot perform add function");
			} catch (RegisterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return user.getUserId();
	}

	@Override
	public boolean searchEmployeeNotNull(Employee emp) {
		Employee emp1;
		emp1 = entityManager.find(Employee.class, emp.getEmpNo());
		if (emp1 == null)
		
		{
		return false;
		}
		else
		{
			return true;
		}
	}

	

	/*@Override
	public boolean validateUser(User user) {
		int userId=user.getUserId();
		User user1;
		try {
			
			user1 = entityManager.find(User.class, userId);
			int userdata=user1.getUserId();
			System.out.println(user1);
			if(userId==(userdata)){
				System.out.println(user);
				return true;
			}
			else{
				throw new RegisterException("Invalid Credential");
			}
		} catch (Exception e) {
			try {
				throw new RegisterException("Invalid Credential");
			} catch (RegisterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
		
	}
	public boolean validateUser(User user, Model model) {
		int userId=user.getUserId();
		User user1;
		try {
			
			user1 = entityManager.find(User.class, userId);
			int userdata=user1.getUserId();
			System.out.println(user1);
			if(userId==(userdata)){
				System.out.println(user);
				return true;
			}
			else{
				throw new RegisterException("Invalid Credentials");
			}
		} catch (Exception e) {
			try {
				throw new RegisterException("Invalid Credential");
			} catch (RegisterException e1) {
				// TODO Auto-generated catch block
				model.addAttribute("errorMessage","Invalid Credentials");
			}
		}
		return false;
	}
		User user1 = entityManager.find(User.class, user.getUserId());
		if(user1==null){
			isValidUser(user);
		}
		else {
			return false;
		}
		return false;
	}
	

	@Override
	public int addUser(User user) throws SQLException {
		try {
			
			entityManager.persist(user);
		} catch (Exception e) {
			try {
				throw new RegisterException("CanNot perform add function");
			} catch (RegisterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return user.getUserId();
		
	}


	@Override
	public boolean validateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		int empNo=emp.getEmpNo();
		Employee emp1;
		try {
			emp1 = entityManager.find(Employee.class, empNo);
			if(emp.equals(emp1)){
				return true;
			}
			else{
				throw new RegisterException("Invalid Credential");
			}
		} catch (Exception e) {
			try {
				throw new RegisterException("Invalid Credential");
			} catch (RegisterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}

	
	public boolean isValidUser(User user){
		Employee employee = entityManager.find(Employee.class,user.getUserId());
		if(employee == null){
			return false;
		}
		else{
			boolean check1 , check2 , check3 = false;
			check1 = (user.getUserName().equals(employee.geteName()));
			check2 = (user.getUserType().toString()).equals("admin");
			check3 = (user.getUserType().toString()).equals("manager");
			
			if(!check1){
				return false;
			}
			else if(check2){
				if(employee.getMgr()!=0){
					return false;
				}
			}
			else if(check3){
				if(employee.getMgr()!=user.getUserId()){
					return false;
				}
			}
			return true;
		}
	}*/
	}

	

