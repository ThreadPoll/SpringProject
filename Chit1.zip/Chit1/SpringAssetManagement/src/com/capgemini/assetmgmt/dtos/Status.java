package com.capgemini.assetmgmt.dtos;

public enum Status {
	inProgress , allocated , rejected;
	
	private Status() {

	}
	
	@Override
	public String toString() {
		return super.toString();
	}
}
