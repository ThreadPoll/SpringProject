package com.capgemini.assetmgmt.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetUserDAO;
import com.capgemini.assetmgmt.daos.AssetUserDAOImpl;
import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Service("userService")
@Transactional
public class AssetUserServiceImpl implements AssetUserService{
	
	@Resource(name="userDao")
	AssetUserDAO userDAO;

	@Override
	public List<Asset> listAsset()
			throws AssetUserException {
		List<Asset> myAssetList = userDAO.listAsset();
		return myAssetList;
	}

	@Override
	public int raiseRequest(AssetAllocation assetAllocation)
			throws AssetUserException {
		return userDAO.raiseRequest(assetAllocation);
	}


	@Override
	public List<Employee> fetchEmployeeList(int userId)
			throws AssetUserException {
		return userDAO.fetchEmployeeList(userId);
	}

	@Override
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation, int userId)
			throws AssetUserException {
		return userDAO.displayRequestStatus(assetAllocation, userId);
	}
}
