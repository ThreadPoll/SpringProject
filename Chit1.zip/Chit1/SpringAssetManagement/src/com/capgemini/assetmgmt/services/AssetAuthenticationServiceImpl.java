package com.capgemini.assetmgmt.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetAuthenticationDAO;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetAuthenticationException;

@Service("assetAuthenticationService")
@Transactional
public class AssetAuthenticationServiceImpl implements AssetAuthenticationService{
	
	@Resource(name="assetAuthenticationDao")
	private AssetAuthenticationDAO authenticationDAO;
	
	@Override
	public boolean isValidUser(User user)
			throws AssetAuthenticationException {
		boolean isCheck = authenticationDAO.isValidUser(user);
		return isCheck;
	}

}
