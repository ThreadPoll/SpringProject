package com.capgemini.assetmgmt.services;

import java.sql.SQLException;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.capgemini.assetmgmt.daos.AssetRegisterDAO;
import com.capgemini.assetmgmt.daos.AssetRegisterDAOImpl;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.RegisterException;

@Service("registerService")
@Transactional
public class AssetRegisterServiceImpl implements AssetRegisterService
{
	@Resource(name="registerDao")
	AssetRegisterDAO registerDao;
	
	public AssetRegisterServiceImpl() {
		registerDao= new AssetRegisterDAOImpl();
	}
	/*@Override
	public boolean validateUser(User user, Model model) {
		return registerDao.validateUser(user, model);
	}

	@Override
	public int addUser(User user) throws SQLException, RegisterException {
		try {
			registerDao.addUser(user);
		} catch (RegisterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return registerDao.addUser(user);
	}
	@Override
	public boolean validateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return registerDao.validateEmployee(emp);
	}
	@Override
	public boolean isValidUser(User user) {
		// TODO Auto-generated method stub
		return registerDao.isValidUser(user);
	}
*/

	@Override
	public boolean searchUser(User user) {
		
		return registerDao.searchUser(user);
	}

	@Override
	public boolean searchEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return registerDao.searchEmployee(emp);
	}

	@Override
	public int addUser(User user) throws SQLException, RegisterException {
		// TODO Auto-generated method stub
		return registerDao.addUser(user);
	}

	@Override
	public boolean searchEmployeeNotNull(Employee emp) {
		// TODO Auto-generated method stub
		return registerDao.searchEmployeeNotNull(emp);
	}
	

}
