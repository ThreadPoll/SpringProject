package com.capgemini.assetmgmt.services;

import java.util.HashMap;
import java.util.List;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

public interface AssetUserService {

	public List<Asset> listAsset() throws AssetUserException;
	public int raiseRequest(AssetAllocation assetAllocation) throws AssetUserException;
	public List<Employee> fetchEmployeeList(int userId) throws AssetUserException;
	public AssetAllocation displayRequestStatus(AssetAllocation assetAllocation, int userId) throws AssetUserException;
}
