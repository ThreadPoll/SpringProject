package com.capgemini.assetmgmt.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.imageio.spi.RegisterableService;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.jboss.resteasy.spi.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.Status;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.dtos.UserType;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;
import com.capgemini.assetmgmt.exceptions.AssetAuthenticationException;
import com.capgemini.assetmgmt.exceptions.AssetUserException;
import com.capgemini.assetmgmt.exceptions.RegisterException;
import com.capgemini.assetmgmt.services.AssetAdminService;
import com.capgemini.assetmgmt.services.AssetAuthenticationService;
import com.capgemini.assetmgmt.services.AssetUserService;
import com.capgemini.assetmgmt.services.AssetRegisterService;

@Controller
public class AssetFrontController {

	@Resource(name="assetAuthenticationService")
	AssetAuthenticationService authenticationService;
	
	@Resource(name="adminService")
	AssetAdminService adminService;
	
	@Resource(name="userService")
	AssetUserService userService;
	
	@Resource(name="registerService")
	AssetRegisterService registerService;
	
	@RequestMapping("/index")
	public String returnHomePage(){
		return "index";
	}
	
	@RequestMapping("/getLoginForm")
	public String getLoginForm(Model model){
		User user = new User();
		model.addAttribute("user",user);
		return "login";
	}
	
	@RequestMapping("/login")
	public String login(@ModelAttribute User user,Model model , HttpServletRequest request){
		request.getSession(true).setAttribute("user", user);
		boolean isValid=false;
		try {
			isValid=authenticationService.isValidUser(user);
			if(isValid){
				model.addAttribute("user",user);
				if((user.getUserType().toString()).equals("admin")){
					return "menuForAdmin";
				}
				else if((user.getUserType().toString()).equals("manager")){
					return "menuForManager";
				}
			}
		} catch (AssetAuthenticationException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "login";
		}
		model.addAttribute("errorMessage","Can not validate the user");
		return "login";
	}
	
	@RequestMapping("/getRegisterForm")
	public String getRegisterForm(Model model){
		User user = new User();
		model.addAttribute("user",user);
		return "newUser";
	}
	
	@RequestMapping("/registerUser")
	
	public String registerUser(@ModelAttribute User user, Employee emp, Model model) throws SQLException, RegisterException
	{
		int uId= user.getUserId();
		boolean flag1= registerService.searchUser(user);
		System.out.println("emp is "+emp);
		boolean flag2= registerService.searchEmployee(emp);
		System.out.println(flag2);
		boolean flag3= registerService.searchEmployeeNotNull(emp);
		System.out.println("After flag 3");
		
		/*if (flag1==true && flag3==false)
		{
			System.out.println("In first if");
			if (flag1==true && flag2==true)
			{
		if (flag1==true && flag2== true && flag3==true)
		{
			flag3=false;*/
			if (flag1==true && flag2==true && flag3==false)
				
				/*if(flag1==true)*/
			
			//if (flag1==true && flag2==true)
		{
			System.out.println(flag2);
			registerService.addUser(user);
		}
			
		
		else
		{
			System.out.println("Invalid.");//This line is only for testing on console.
		}
		
		
		
		return "newUser";
		
}
	/*public String registerUser(@ModelAttribute User user,Employee emp, Model model) throws SQLException, RegisterException
	{
		//boolean flag=registerService.validateUser(user, model);
		boolean flag = registerService.isValidUser(user);
		if(flag==true){
		try {
			int userId = registerService.addUser(user);
			model.addAttribute("userId",userId);
		} catch (RegisterException e) {
			model.addAttribute("errorMessage","Can't be added.");
			return "newUser";
		}
		
		}
		else
		{
			model.addAttribute("errorMessage","This user already exists.");
			return "newUser";
		}
		return "newUser";
	}*/
	
	@RequestMapping("/getAddAssetForm")
	public String getAddAssetForm(Model model){
		Asset asset = new Asset();
		model.addAttribute(asset);
		return "addAssetAdmin";
	}
	
	@RequestMapping("/addAssetAdmin")
	public String addAssetAdmin(@ModelAttribute @Valid Asset asset ,BindingResult result , Model model){
		if(result.hasErrors()){
			System.out.println(result.getErrorCount()+"sfgsd"+result.getAllErrors());
			return "addAssetAdmin";
		}
		try {
			int assetId = adminService.addAsset(asset);
			model.addAttribute("assetId",assetId);
		} catch (AssetAdminException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "addAssetAdmin";
		}
		return "assetAddedAdmin";
	}
	
	@RequestMapping("/getUpdateAssetForm")
	public String getUpdateAssetForm(Model model){
		Asset asset = new Asset();
		model.addAttribute("asset",asset);
		return "updateAssetAdmin";
	}
	
	@RequestMapping("/fetchAssetAdmin")
	public String fetchAssetAdmin(@ModelAttribute Asset asset , Model model){
		int assetId = asset.getAssetId();
		try {
			asset = adminService.searchAsset(assetId);
			model.addAttribute("asset",asset);
		} catch (AssetAdminException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "updateAssetAdmin";
		}
		return "updateAssetAdmin";
	}
	
	@RequestMapping("/updateAssetAdmin")
	public String updateAssetAdmin(@ModelAttribute Asset asset , Model model){
		try {
			adminService.updateAsset(asset);
		} catch (AssetAdminException e) {
			model.addAttribute("errorMessage1",e.getMessage());
			return "updateAssetAdmin";
		}
		return "menuForAdmin";
	}
	
	@RequestMapping("/displayRequestAdmin")
	public String displayRequestAdmin(Model model){
		try {
			List<AssetAllocation> requestList = adminService.displayRequest();
			model.addAttribute("requestList",requestList);
		} catch (AssetAdminException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "requestListAdmin";
		}
		return "requestListAdmin";
	}
	
	@RequestMapping("/viewAllAsset")
	public String viewAllAsset(Model model){
		try {
			List<Asset> assetList = userService.listAsset();
			model.addAttribute("assetList",assetList);
		} catch (AssetUserException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "getAllAssetManager";
		}
		return "getAllAssetManager";
	}
	
	@RequestMapping("/getRequestForm")
	public String getRequestForm(Model model , HttpServletRequest request){
		User user = (User) request.getSession(false).getAttribute("user");
		Asset asset = new Asset();
		AssetAllocation assetAllocation = new AssetAllocation();
		assetAllocation.setAsset(asset);
		model.addAttribute("assetAllocation",assetAllocation);
		try {
			List<Employee> employeeList = userService.fetchEmployeeList(user.getUserId());
			model.addAttribute("employeeList",employeeList);
			request.getSession(false).setAttribute("employeeList", employeeList);
		} catch (AssetUserException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "oops";
		}
		return "raiseRequestManager";
	}
	
	@RequestMapping("/postRequestRaise")
	public String postRequestRaise(@ModelAttribute @Valid AssetAllocation assetAllocation ,BindingResult result, Model model , HttpServletRequest request){
		/*SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		User user = (User) request.getSession(false).getAttribute("user");
		Date allocationDate = assetAllocation.getAllocationDate();
		Date releaseDate = assetAllocation.getReleaseDate();
		
		Date allocationDate = null;
		Date releaseDate = null;
		try {
			java.util.Date aDate = formatter1.parse(alloDate);
			java.util.Date rDate = formatter1.parse(relDate);
			
			String allocDate1 = formatter.format(aDate);
			String releDate1 = formatter.format(rDate);
			
			java.util.Date allocDate = formatter.parse(allocDate1);
			java.util.Date releDate = formatter.parse(releDate1);
			
			allocationDate = new Date(allocDate.getTime());
			releaseDate = new Date(releDate.getTime());
			
			
		} catch (ParseException e1) {
			e1.printStackTrace();
			model.addAttribute("errorMessage",e1.getMessage());
			return "oops";
		}*/
		
		if(result.hasErrors()){
			return "raiseRequestManager";
		}
		
		int flag = 0;
		@SuppressWarnings("unchecked")
		List<Employee> empList = (List<Employee>) request.getSession(false).getAttribute("employeeList");
		
		try {
			if(assetAllocation.getAllocationDate().after(assetAllocation.getReleaseDate())){
				model.addAttribute("error", "Release date is incorrect");
				/*Asset asset = new Asset();
				asset.setAssetId(assetAllocation.getAsset().getAssetId());
				AssetAllocation assetAllocation2 = new AssetAllocation();
				assetAllocation2.setAsset(asset);*/
				model.addAttribute("assetAllocation",assetAllocation);
				/*try {
					List<Employee> employeeList = userService.fetchEmployeeList(user.getUserId());
					model.addAttribute("employeeList",employeeList);
					request.getSession(false).setAttribute("employeeList", employeeList);
				} catch (AssetUserException e) {
					model.addAttribute("errorMessage",e.getMessage());
					return "oops";
				}*/
				return "raiseRequestManager";
			}
			for(int index=0 ; index<empList.size() ; index++){
				int empNo = empList.get(index).getEmpNo();
				if(empNo == assetAllocation.getEmpNo()){
					flag = 1;
				}
			}
			
			if(flag == 0){
				model.addAttribute("error1", "You cannot raise request for this employee");
				Asset asset = new Asset();
				asset.setAssetId(assetAllocation.getAsset().getAssetId());
				AssetAllocation assetAllocation2 = new AssetAllocation();
				assetAllocation2.setAsset(asset);
				assetAllocation2.setEmpNo(assetAllocation.getEmpNo());
				model.addAttribute("assetAllocation",assetAllocation);
				return "raiseRequestManager";
			}
			Asset asset = adminService.searchAsset(assetAllocation.getAsset().getAssetId());
			assetAllocation.setStatus(Status.inProgress);
			assetAllocation.setAsset(asset);
			System.out.println("asset Allocation is :"+assetAllocation);
			int allocationId = userService.raiseRequest(assetAllocation);
			model.addAttribute("allocationId",allocationId);
		} catch (AssetUserException | AssetAdminException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "raiseRequestManager";
		}
		return "postRequestManager";
	}
	
	@RequestMapping("/getActionDetails")
	public String getActionDetails(@RequestParam("id") int allocationId , @RequestParam("action") String action , Model model){
		if(action.equals("approve")){
			try {
				adminService.actRequestAdmin(Status.allocated.toString(), allocationId);
			} catch (AssetAdminException e) {
				model.addAttribute("errorMessage",e.getMessage());
				return "oops";
			}
		}else if(action.equals("reject")){
			try {
				adminService.actRequestAdmin(Status.rejected.toString(), allocationId);
			} catch (AssetAdminException e) {
				model.addAttribute("errorMessage",e.getMessage());
				return "oops";
			}
		}
		return "requestListAdmin";
	}
	
	@RequestMapping("/getfetchRequestForm")
	public String getfetchRequestForm(Model model){
		AssetAllocation assetAllocation = new AssetAllocation();
		model.addAttribute("assetAllocation", assetAllocation);
		return "fetchRequestStatusManager";
	}
	
	@RequestMapping("/fetchRequsetStatus")
	public String fetchRequsetStatus(@ModelAttribute AssetAllocation assetAllocation ,Model model, HttpServletRequest request){
		try {
			User user = (User) request.getSession(false).getAttribute("user");
			assetAllocation = userService.displayRequestStatus(assetAllocation ,user.getUserId());
			model.addAttribute("assetAllocation", assetAllocation);
		} catch (AssetUserException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "fetchRequestStatusManager";
		}
		return "fetchRequestStatusManager";
	}
}
