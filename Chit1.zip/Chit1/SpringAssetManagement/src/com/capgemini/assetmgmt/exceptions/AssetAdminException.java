package com.capgemini.assetmgmt.exceptions;

public class AssetAdminException extends Exception {

	private static final long serialVersionUID = -2182096989746821065L;

	public AssetAdminException() {
		super();
	}

	public AssetAdminException(String arg0) {
		super(arg0);
	}

	public AssetAdminException(Throwable arg0) {
		super(arg0);
	}

	
}
