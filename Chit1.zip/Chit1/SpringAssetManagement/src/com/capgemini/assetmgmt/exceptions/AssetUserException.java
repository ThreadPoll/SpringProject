package com.capgemini.assetmgmt.exceptions;

public class AssetUserException extends Exception {

	private static final long serialVersionUID = -2812135409839952574L;

	public AssetUserException() {
		super();
	}

	public AssetUserException(String arg0) {
		super(arg0);
	}

	public AssetUserException(Throwable arg0) {
		super(arg0);
	}

	
}
