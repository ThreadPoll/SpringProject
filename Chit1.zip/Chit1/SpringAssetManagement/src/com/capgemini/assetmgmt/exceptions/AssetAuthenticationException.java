package com.capgemini.assetmgmt.exceptions;

public class AssetAuthenticationException extends Exception {

	private static final long serialVersionUID = 1892038293583260886L;

	public AssetAuthenticationException() {
		super();
	}

	public AssetAuthenticationException(String arg0) {
		super(arg0);
	}

	public AssetAuthenticationException(Throwable arg0) {
		super(arg0);
	}

	
}
