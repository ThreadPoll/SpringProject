package com.capgemini.assetmgmt.exceptions;

public class RegisterException extends Exception
{

	public RegisterException(String message) {
		super(message);
		
	}

	public RegisterException(Throwable cause) {
		super(cause);
	}
	
}
