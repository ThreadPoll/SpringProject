drop table user_master cascade constraints;
create table user_master(
userid number primary key,
username varchar2(20),
userpassword varchar2(20),
usertype varchar2(20)
);

insert into user_master values(1001,'Girjesh'	,'pass@123',	'admin'  );
insert into user_master values(1002,'Aman'		,'pass@123',	'admin'  );
insert into user_master values(1003,'Khushboo'	,'pass@123',	'admin'  );
insert into user_master values(1004,'Divakar'	,'pass@123',	'admin'  );
insert into user_master values(1005,'Nidhi'	,'pass@123',	'admin'  );
insert into user_master values(1006,'Sneha'	,'pass@123',	'manager');
insert into user_master values(1007,'Chitranjan','pass@123',	'manager');
insert into user_master values(1008,'Harshita'	,'pass@123',	'manager');
insert into user_master values(1009,'Namita'	,'pass@123',	'manager');
insert into user_master values(1010,'Ashok'	,'pass@123',	'manager');


drop table Department cascade constraints;
CREATE TABLE Department(
Dept_ID int PRIMARY KEY,
Dept_name varchar2(50)
);

insert into Department values(10,'Java');
insert into Department values(20,'Oracle');
insert into Department values(30,'MainFrame');
insert into Department values(40,'Business Intellegence');
insert into Department values(50,'Financial Services');

drop table Employee cascade constraints;
CREATE TABLE Employee(
Empno Number(6) PRIMARY KEY,
Ename varchar2(25),
job varchar2(50),
mgr Number(4),
hiredate date,
dept_id int,
foreign key (dept_id) references Department(dept_id)
);

insert into Employee values(1001,'Girjesh'	,	'Admin'   						,	null,'06-NOV-2016',10);
insert into Employee values(1002,'Aman'		,	'Admin'   						,	null,'17-NOV-1995',30);
insert into Employee values(1003,'Khushboo'	,	'Admin'   						,	null,'14-AUG-1980',20);
insert into Employee values(1004,'Divakar'	,	'Admin'   						,	null,'17-JAN-1999',40);
insert into Employee values(1005,'Nidhi'	,	'Admin'   						,	null,'20-DEC-2000',50);
insert into Employee values(1006,'Sneha'	,	'MainFrame Manager'   			,	1006,'01-FEB-2002',30);
insert into Employee values(1007,'Chitranjan',	'Oracle Manager'   				,	1007,'30-NOV-2004',20);
insert into Employee values(1008,'Harshita'	,	'Financial Services Manager'	,	1008,'08-MAR-2007',50);
insert into Employee values(1009,'Namita'	,	'Java Manager'   				,	1009,'24-APR-2004',10);
insert into Employee values(1010,'Ashok'	,	'Business Intelligence Manager'	,	1010,'09-JUN-2010',40);
insert into Employee values(1011,'Varsha'	,	'Database Engineer'   			,	1007,'10-JUL-2000',50);
insert into Employee values(1012,'Vishal'	,	'Software Engineer'   			,	1008,'22-SEP-2012',10);
insert into Employee values(1013,'Samarth'	,	'EnterPrises Engineer' 			,	1010,'27-OCT-1997',20);
insert into Employee values(1014,'Tanmay'	,	'Database Engineer'   			,	1009,'20-APR-1999',50);
insert into Employee values(1015,'Rajat'	,	'Financial Engineer'   			,	1006,'14-DEC-2001',40);
insert into Employee values(1016,'Omkar'	,	'Testing Engineer'   			,	1008,'10-JAN-1997',30);
insert into Employee values(1017,'Chirag'	,	'Database Engineer'   			,	1007,'31-DEC-2012',10);
insert into Employee values(1018,'Ibrahim'	,	'Software Engineer'   			,	1010,'01-NOV-2014',30);
insert into Employee values(1019,'Mohit'	,	'Financial Services Engineer'   ,	1009,'21-MAR-2016',40);
insert into Employee values(1020,'Umang'	,	'Network Analyst'   			,	1008,'21-MAR-2001',50);
insert into Employee values(1021,'Akansha'	,	'Database Engineer'   			,	1010,'03-APR-2014',40);
insert into Employee values(1022,'Rushika'	,	'Software Engineer'   			,	1006,'14-AUG-2000',10);
insert into Employee values(1023,'Lalak'	,	'Testing Engineer'   			,	1007,'10-JUL-2001',20);
insert into Employee values(1024,'Nupur'	,	'Financial Services Manager'   	,	1008,'13-SEP-2004',40);
insert into Employee values(1025,'Tanu'		,	'EnterPrises Engineer'   		,	1006,'23-JUN-2010',30);
insert into Employee values(1026,'Sapna'	,	'Financial Services Engineer'   ,	1008,'24-AUG-1999',30);
insert into Employee values(1027,'Vinod'	,	'Database Engineer'   			,	1010,'05-NOV-2015',50);
insert into Employee values(1028,'Ity'		,	'Network Analyst'   			,	1009,'17-MAR-2000',10);
insert into Employee values(1029,'Farheen'	,	'Software Engineer'   			,	1006,'28-MAY-2014',20);
insert into Employee values(1030,'Heena'	,	'EnterPrises Engineer'   		,	1007,'10-OCT-2016',40);
insert into Employee values(1031,'Urvashi'	,	'Testing Engineer'   			,	1008,'15-APR-2000',20);
insert into Employee values(1032,'Sakshi'	,	'Financial Services Engineer'  	,	1009,'24-MAR-2003',30);
insert into Employee values(1033,'Shruti'	,	'Database Engineer'   			,	1010,'20-JAN-2004',50);
insert into Employee values(1034,'Shikhar'	,	'Network Analyst'   			,	1007,'14-FEB-2007',40);
insert into Employee values(1035,'Karan'	,	'EnterPrises Engineer'   		,	1009,'20-MAR-2010',10);
insert into Employee values(1036,'Saurabh'	,	'Software Engineer'   			,	1007,'25-DEC-1999',20);
insert into Employee values(1037,'Prathu'	,	'Testing Engineer'   			,	1009,'13-MAR-2000',30);
insert into Employee values(1038,'Yogesh'	,	'Software Engineer'   			,	1007,'13-APR-2002',40);
insert into Employee values(1039,'John'		,	'Financial Services Engineer'   ,	1006,'29-JUL-2014',50);
insert into Employee values(1040,'Sam'		,	'Database Engineer'   			,	1008,'12-OCT-1998',30);
insert into Employee values(1041,'Eric'		,	'EnterPrises Engineer'   		,	1006,'10-MAR-2003',20);
insert into Employee values(1042,'Tommy'	,	'Database Engineer'   			,	1007,'05-JUL-2005',40);
insert into Employee values(1043,'Lawrene'	,	'Network Analyst'   			,	1010,'24-AUG-2005',50);
insert into Employee values(1044,'Nishan'	,	'Software Engineer'   			,	1009,'05-NOV-2005',10);
insert into Employee values(1045,'Smith'	,	'EnterPrises Engineer'   		,	1010,'14-SEP-2008',30);
insert into Employee values(1046,'Shawn'	,	'Associate Engineer'   			,	1009,'14-OCT-2004',40);
insert into Employee values(1047,'James'	,	'Associate Engineer'   			,	1006,'09-NOV-1997',50);
insert into Employee values(1048,'Kelly'	,	'Network Engineer'   			,	1008,'01-JAN-2000',20);
insert into Employee values(1049,'Simmy'	,	'Database Engineer'   			,	1007,'04-MAR-2002',40);
insert into Employee values(1050,'Vatsal'	,	'Financial Services Engineer'   ,	1009,'24-JUL-2008',50);
insert into Employee values(1051,'Lee'		,	'Testing Engineer'   			,	1007,'21-MAR-2009',20);
insert into Employee values(1052,'Jimmy'	,	'Associate Engineer'   			,	1007,'10-FEB-2010',40);
insert into Employee values(1053,'Payal'	,	'Network Engineer'   			,	1008,'27-MAR-2011',10);
insert into Employee values(1054,'Sia'		,	'Database Engineer'   			,	1010,'13-JUN-2012',20);
insert into Employee values(1055,'Shayma'	,	'Network Engineer'   			,	1009,'26-NOV-2005',50);
insert into Employee values(1056,'Sinkon'	,	'Associate Engineer'   			,	1010,'31-OCT-2007',10);
insert into Employee values(1057,'Yang'		,	'Database Engineer'   			,	1007,'14-NOV-1995',30);
insert into Employee values(1058,'Krisha'	,	'Financial Services Manager'   	,	1008,'20-JUL-2008',40);
insert into Employee values(1059,'Prisha'	,	'Associate Engineer'   			,	1009,'17-NOV-2010',50);
insert into Employee values(1060,'Devansh'	,	'Associate Engineer'   			,	1007,'07-DEC-2012',20);

drop table Asset cascade constraints;
CREATE TABLE Asset(
AssetId Number PRIMARY KEY,
AssetName varchar2(25),
AssetDes varchar2(25),
Quantity number,
Status varchar2(15)
);

drop table asset_Allocation cascade constraints;
CREATE TABLE Asset_Allocation(
AllocationId number PRIMARY KEY,
AssetId number,
Empno number,
Allocation_date date,
Release_date date,
foreign key (AssetId) references Asset(AssetId),
foreign key (Empno) references Employee(Empno)
);


CREATE SEQUENCE generate_allocation_id START WITH 10000;

CREATE SEQUENCE generate_asset_id START WITH 100;
commit;

