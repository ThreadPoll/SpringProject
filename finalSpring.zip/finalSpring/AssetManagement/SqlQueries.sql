/*Accept and reject button color*/

drop table user_master cascade constraints;
create table user_master(
userid number,
username varchar2(20),
userpassword varchar2(20),
usertype varchar2(20)
);

insert into user_master values(1001,'Girjesh'	,'pass@123',	'admin'  );
insert into user_master values(1002,'Aman'		,'pass@123',	'admin'  );
insert into user_master values(1003,'Khushboo'	,'pass@123',	'admin'  );
insert into user_master values(1004,'Divakar'	,'pass@123',	'admin'  );
insert into user_master values(1005,'Nidhi'	,'pass@123',	'admin'  );
insert into user_master values(1006,'Sneha'	,'pass@123',	'manager');
insert into user_master values(1007,'Chitranjan','pass@123',	'manager');
insert into user_master values(1008,'Harshita'	,'pass@123',	'manager');
insert into user_master values(1009,'Namita'	,'pass@123',	'manager');
insert into user_master values(1010,'Ashok'	,'pass@123',	'manager');


drop table Department cascade constraints;
CREATE TABLE Department(
Dept_ID int PRIMARY KEY,
Dept_name varchar2(50)
);

insert into Asset_Department values(10,'Java');
insert into Asset_Department values(20,'Oracle');
insert into Asset_Department values(30,'MainFrame');
insert into Asset_Department values(40,'Business Intellegence');
insert into Asset_Department values(50,'Financial Services');

drop table Asset_Employee cascade constraints;
CREATE TABLE Employee(
Empno Number(6) PRIMARY KEY,
Ename varchar2(25),
job varchar2(50),
mgr Number(4),
hiredate date,
dept_id int,
foreign key (dept_id) references Department(dept_id)
);

insert into Asset_Employee values(1001,'Girjesh'	,'06-NOV-2016',	'Admin'   						,	null,10);
insert into Asset_Employee values(1002,'Aman'		,'17-NOV-1995',	'Admin'   						,	null,30);
insert into Asset_Employee values(1003,'Khushboo'	,'14-AUG-1980',	'Admin'   						,	null,20);
insert into Asset_Employee values(1004,'Divakar'	,'17-JAN-1999',	'Admin'   						,	null,40);
insert into Asset_Employee values(1005,'Nidhi'		,'20-DEC-2000',	'Admin'   						,	null,50);
insert into Asset_Employee values(1006,'Sneha'		,'01-FEB-2002',	'MainFrame Manager'   			,	1006,30);
insert into Asset_Employee values(1007,'Chitranjan'	,'30-NOV-2004',	'Oracle Manager'   				,	1007,20);
insert into Asset_Employee values(1008,'Harshita'	,'08-MAR-2007',	'Financial Services Manager'	,	1008,50);
insert into Asset_Employee values(1009,'Namita'		,'24-APR-2004',	'Java Manager'   				,	1009,10);
insert into Asset_Employee values(1010,'Ashok'		,'09-JUN-2010',	'Business Intelligence Manager'	,	1010,40);
insert into Asset_Employee values(1011,'Varsha'		,'10-JUL-2000',	'Database Engineer'   			,	1007,50);
insert into Asset_Employee values(1012,'Vishal'		,'22-SEP-2012',	'Software Engineer'   			,	1008,10);
insert into Asset_Employee values(1013,'Samarth'	,'27-OCT-1997',	'EnterPrises Engineer' 			,	1010,20);
insert into Asset_Employee values(1014,'Tanmay'		,'20-APR-1999',	'Database Engineer'   			,	1009,50);
insert into Asset_Employee values(1015,'Rajat'		,'14-DEC-2001',	'Financial Engineer'   			,	1006,40);
insert into Asset_Employee values(1016,'Omkar'		,'10-JAN-1997',	'Testing Engineer'   			,	1008,30);
insert into Asset_Employee values(1017,'Chirag'		,'31-DEC-2012',	'Database Engineer'   			,	1007,10);
insert into Asset_Employee values(1018,'Ibrahim'	,'01-NOV-2014',	'Software Engineer'   			,	1010,30);
insert into Asset_Employee values(1019,'Mohit'		,'21-MAR-2016',	'Financial Services Engineer'   ,	1009,40);
insert into Asset_Employee values(1020,'Umang'		,'21-MAR-2001',	'Network Analyst'   			,	1008,50);
insert into Asset_Employee values(1021,'Akansha'	,'03-APR-2014',	'Database Engineer'   			,	1010,40);
insert into Asset_Employee values(1022,'Rushika'	,'14-AUG-2000',	'Software Engineer'   			,	1006,10);
insert into Asset_Employee values(1023,'Lalak'		,'10-JUL-2001',	'Testing Engineer'   			,	1007,20);
insert into Asset_Employee values(1024,'Nupur'		,'13-SEP-2004',	'Financial Services Manager'   	,	1008,40);
insert into Asset_Employee values(1025,'Tanu'		,'23-JUN-2010',	'EnterPrises Engineer'   		,	1006,30);
insert into Asset_Employee values(1026,'Sapna'		,'24-AUG-1999',	'Financial Services Engineer'   ,	1008,30);
insert into Asset_Employee values(1027,'Vinod'		,'05-NOV-2015',	'Database Engineer'   			,	1010,50);
insert into Asset_Employee values(1028,'Ity'		,'17-MAR-2000',	'Network Analyst'   			,	1009,10);
insert into Asset_Employee values(1029,'Farheen'	,'28-MAY-2014',	'Software Engineer'   			,	1006,20);
insert into Asset_Employee values(1030,'Heena'		,'10-OCT-2016',	'EnterPrises Engineer'   		,	1007,40);
insert into Asset_Employee values(1031,'Urvashi'	,'15-APR-2000',	'Testing Engineer'   			,	1008,20);
insert into Asset_Employee values(1032,'Sakshi'		,'24-MAR-2003',	'Financial Services Engineer'  	,	1009,30);
insert into Asset_Employee values(1033,'Shruti'		,'20-JAN-2004',	'Database Engineer'   			,	1010,50);
insert into Asset_Employee values(1034,'Shikhar'	,'14-FEB-2007',	'Network Analyst'   			,	1007,40);
insert into Asset_Employee values(1035,'Karan'		,'20-MAR-2010',	'EnterPrises Engineer'   		,	1009,10);
insert into Asset_Employee values(1036,'Saurabh'	,'25-DEC-1999',	'Software Engineer'   			,	1007,20);
insert into Asset_Employee values(1037,'Prathu'		,'13-MAR-2000',	'Testing Engineer'   			,	1009,30);
insert into Asset_Employee values(1038,'Yogesh'		,'13-APR-2002',	'Software Engineer'   			,	1007,40);
insert into Asset_Employee values(1039,'John'		,'29-JUL-2014',	'Financial Services Engineer'   ,	1006,50);
insert into Asset_Employee values(1040,'Sam'		,'12-OCT-1998',	'Database Engineer'   			,	1008,30);
insert into Asset_Employee values(1041,'Eric'		,'10-MAR-2003',	'EnterPrises Engineer'   		,	1006,20);
insert into Asset_Employee values(1042,'Tommy'		,'05-JUL-2005',	'Database Engineer'   			,	1007,40);
insert into Asset_Employee values(1043,'Lawrene'	,'24-AUG-2005',	'Network Analyst'   			,	1010,50);
insert into Asset_Employee values(1044,'Nishan'		,'05-NOV-2005',	'Software Engineer'   			,	1009,10);
insert into Asset_Employee values(1045,'Smith'		,'14-SEP-2008',	'EnterPrises Engineer'   		,	1010,30);
insert into Asset_Employee values(1046,'Shawn'		,'14-OCT-2004',	'Associate Engineer'   			,	1009,40);
insert into Asset_Employee values(1047,'James'		,'09-NOV-1997',	'Associate Engineer'   			,	1006,50);
insert into Asset_Employee values(1048,'Kelly'		,'01-JAN-2000',	'Network Engineer'   			,	1008,20);
insert into Asset_Employee values(1049,'Simmy'		,'04-MAR-2002',	'Database Engineer'   			,	1007,40);
insert into Asset_Employee values(1050,'Vatsal'		,'24-JUL-2008',	'Financial Services Engineer'   ,	1009,50);
insert into Asset_Employee values(1051,'Lee'		,'21-MAR-2009',	'Testing Engineer'   			,	1007,20);
insert into Asset_Employee values(1052,'Jimmy'		,'10-FEB-2010',	'Associate Engineer'   			,	1007,40);
insert into Asset_Employee values(1053,'Payal'		,'27-MAR-2011',	'Network Engineer'   			,	1008,10);
insert into Asset_Employee values(1054,'Sia'		,'13-JUN-2012',	'Database Engineer'   			,	1010,20);
insert into Asset_Employee values(1055,'Shayma'		,'26-NOV-2005',	'Network Engineer'   			,	1009,50);
insert into Asset_Employee values(1056,'Sinkon'		,'31-OCT-2007',	'Associate Engineer'   			,	1010,10);
insert into Asset_Employee values(1057,'Yang'		,'14-NOV-1995',	'Database Engineer'   			,	1007,30);
insert into Asset_Employee values(1058,'Krisha'		,'20-JUL-2008',	'Financial Services Manager'   	,	1008,40);
insert into Asset_Employee values(1059,'Prisha'		,'17-NOV-2010',	'Associate Engineer'   			,	1009,50);
insert into Asset_Employee values(1060,'Devansh'	,'07-DEC-2012',	'Associate Engineer'   			,	1007,20);

drop table Asset cascade constraints;
CREATE TABLE Asset(
AssetId Number PRIMARY KEY,
AssetName varchar2(25),
AssetDes varchar2(25),
Quantity number,
Status varchar2(15)
);

drop table asset_Allocation cascade constraints;
CREATE TABLE Asset_Allocation(
AllocationId number PRIMARY KEY,
AssetId number,
Empno number,
Allocation_date date,
Release_date date,
foreign key (AssetId) references Asset(AssetId),
foreign key (Empno) references Employee(Empno)
);


CREATE SEQUENCE generate_allocation_id START WITH 10000;

CREATE SEQUENCE generate_asset_id START WITH 100;
commit;

