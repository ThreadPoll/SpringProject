package com.capgemini.assetmgmt.daos;

import java.util.List;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetEmployeeException;

/*Interface for abstract methods of Employee Dao Functions*/
public interface AssetEmployeeDAO {
	public Employee findEmployee(int empNo) throws AssetEmployeeException;
	public List<Employee> getEmployeeList() throws AssetEmployeeException;
}
