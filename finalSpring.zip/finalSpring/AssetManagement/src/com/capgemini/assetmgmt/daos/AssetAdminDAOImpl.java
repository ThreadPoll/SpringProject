package com.capgemini.assetmgmt.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Asset;
import com.capgemini.assetmgmt.dtos.AssetAllocation;
import com.capgemini.assetmgmt.dtos.Status;
import com.capgemini.assetmgmt.exceptions.AssetAdminException;

@Repository("adminDao")
public class AssetAdminDAOImpl implements AssetAdminDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	/*
	 * 1. Add Asset
	 * 2. Update Asset
	 * 3. Search Asset
	 * 4. Display List of Assets Requests
	 * 5. Act on the request Raised by manager
	*/
	
	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	
	@Override
	public int addAsset(Asset asset) throws AssetAdminException {
		try {
			entityManager.persist(asset);
			myLogger.info("Asset Added in Table.");
		} catch (Exception e) {
			throw new AssetAdminException("CanNot perform add function");
		}
		return asset.getAssetId();
	}

	@Override
	public void updateAsset(Asset asset) throws AssetAdminException {
		try {
			entityManager.merge(asset);
			myLogger.info("Asset Updated in Table.");
		} catch (Exception e) {
			throw new AssetAdminException("Can Not Update Asset");
		}
	}

	@Override
	public Asset searchAsset(int assetId) throws AssetAdminException {
		Asset asset = null;
		try {
			asset = entityManager.find(Asset.class, assetId);
			myLogger.info("Asset Found from Table.");
		} catch (Exception e) {
			throw new AssetAdminException("Can Not fetch the asset");
		}
		
		try {
			if(asset==null){
				throw new AssetAdminException("Asset ID Not found");
			}
		} catch (Exception e) {
			throw new AssetAdminException(e.getMessage());
		}
		
		return asset;
	}

	@Override
	public List<AssetAllocation> displayRequest() throws AssetAdminException {
		List<AssetAllocation> requestList = null;
		try {
			TypedQuery<AssetAllocation> query = entityManager.createQuery("SELECT a FROM assetAllocation a WHERE status NOT IN('allocated','rejected')",AssetAllocation.class);
			/*"+Status.allocated.toString()+","+Status.rejected.toString()+")*/
			requestList = query.getResultList();
			myLogger.info("Request List is fetched from table.");
		} catch (Exception e) {
			throw new AssetAdminException("Unable to fetch requestList");
		}
		return requestList;
	}

	@Override
	public void actRequestAdmin(String act, int allocationId)
			throws AssetAdminException {
		AssetAllocation assetAllocation = null;
		try {
			assetAllocation = entityManager.find(AssetAllocation.class, allocationId);
			assetAllocation.setStatus(Status.valueOf(act));
			assetAllocation = entityManager.merge(assetAllocation);
			myLogger.info("Status changed in table.");
		} catch (Exception e) {
			throw new AssetAdminException("Can Not fetch the asset");
		}
	}
}