package com.capgemini.assetmgmt.daos;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Repository("assetUserDao")

public class AssetUserDAOImpl implements AssetUserDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	/*
	 * 1. Check the user is valid or not.
	 * 2. Register the user in table.
	*/	
	
	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	@Override
	public boolean isValidUser(User user) throws AssetUserException {
		int userId=user.getUserId();
		User user1;
		try {
			user1 = entityManager.find(User.class, userId);
			if(user.equals(user1)){
				myLogger.info("User is validated");
				return true;
			}
			else{
				throw new AssetUserException("Invalid Credential");
			}
		} catch (Exception e) {
			throw new AssetUserException("Invalid Credential");
		}
		
	}
	@Override
	public boolean register(User user, String confirmPass) throws AssetUserException {
		boolean isEmployee;
		try {
			isEmployee = isEmployee(user);
		} catch (Exception e1) {
			throw new AssetUserException(e1.getMessage());
		}
		if(isEmployee){
			boolean isExistingUser;
				try {
					isExistingUser = isExistingUser(user);
					if(isExistingUser){
						throw new AssetUserException("You are already registered with this id !!! Kindly login again");
					}
				} catch (Exception e) {
					throw new AssetUserException(e.getMessage());
				}
			if(! isExistingUser){
				entityManager.persist(user);
				myLogger.info("New User is registered");
				return true;
			}
		}
		return false;
	}
	
	private boolean isExistingUser(User user) throws AssetUserException {
		try {
			User user1 = entityManager.find(User.class , user.getUserId());
			if(user1 != null){
				if(user.getUserId()==user1.getUserId()){
					return true;
				}
			}
		} catch (Exception e) {
			
			throw new AssetUserException("Can not check existing account of user");
		}
		return false;
	}
	public boolean isEmployee(User user) throws AssetUserException{
		Employee employee = new Employee();
		int flag = 0;
		try {
			employee = entityManager.find(Employee.class, user.getUserId());
		} catch (Exception e) {
			myLogger.debug("Existence of employee can not be confirmed");
		}
		
		if((employee != null)&&(user.getUserName().equals(employee.geteName()))){
			if(user.getUserType().toString().equals("admin")){
				if(employee.getMgr() == null){
					flag=1;
				}
			}else if(user.getUserType().toString().equals("manager")){
				if((employee.getMgr() != null) && (employee.getMgr()==user.getUserId())){
					flag=1;
				}
			}
		}
		if(flag==1){
			return true;
		}
		else{
			throw new AssetUserException("Invalid Credential!!! Please check again");
		}
	}

}
