package com.capgemini.assetmgmt.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetEmployeeException;

@Repository("employeeDao")
public class AssetEmployeeDAOImpl implements AssetEmployeeDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	/*
	 * 1. Find an employee based on Employee Id.
	 * 2. Find employee list
	*/
	
	private static final Logger myLogger=
			Logger.getLogger(AssetAdminDAOImpl.class);
	
	@Override
	public Employee findEmployee(int empNo) throws AssetEmployeeException {
		Employee employee = null;
		try {
			employee = entityManager.find(Employee.class, empNo);
			if(employee==null){
				throw new AssetEmployeeException("Employee Id does not exist");
			}
		} catch (Exception e) {
			myLogger.debug("Employee can not be found");
			throw new AssetEmployeeException(e.getMessage());
		}
		return employee;
	}

	@Override
	public List<Employee> getEmployeeList() throws AssetEmployeeException {
		List<Employee> empList = null;
		try {
			TypedQuery<Employee> query = entityManager.createQuery("SELECT emp FROM eemployee emp",Employee.class);
			empList = query.getResultList();
		} catch (Exception e) {
			myLogger.debug("Employee list can not be fetched");
		}
		return empList;
	}

}
