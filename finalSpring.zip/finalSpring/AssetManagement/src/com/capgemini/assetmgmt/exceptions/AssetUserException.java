package com.capgemini.assetmgmt.exceptions;

public class AssetUserException extends Exception{

	private static final long serialVersionUID = 1L;

	public AssetUserException() {
		super();
	}

	public AssetUserException(String message, Throwable cause) {
		super(message, cause);
	}

	public AssetUserException(String message) {
		super(message);
	}

	public AssetUserException(Throwable cause) {
		super(cause);
	}
	
}
