package com.capgemini.assetmgmt.exceptions;

public class AssetAdminException extends Exception{

	private static final long serialVersionUID = 1L;

	public AssetAdminException() {
		super();
	}

	public AssetAdminException(String message, Throwable cause) {
		super(message, cause);
	}

	public AssetAdminException(String message) {
		super(message);
	}

	public AssetAdminException(Throwable cause) {
		super(cause);
	}

	
}
