package com.capgemini.assetmgmt.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetEmployeeDAO;
import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetEmployeeException;

@Service("employeeService")
@Transactional
public class AssetEmployeeServiceImpl implements AssetEmployeeService {

	@Resource(name="employeeDao")
	AssetEmployeeDAO employeeDao;
	
	/*
	 * 1. Find an employee based on Employee Id.
	 * 2. Find employee list
	*/
	
	@Override
	public Employee findEmployee(int empNo) throws AssetEmployeeException {
		return employeeDao.findEmployee(empNo);
	}

	@Override
	public List<Employee> getEmployeeList() throws AssetEmployeeException {
		return employeeDao.getEmployeeList();
	}

}
