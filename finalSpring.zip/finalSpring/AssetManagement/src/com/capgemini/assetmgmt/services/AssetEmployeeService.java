package com.capgemini.assetmgmt.services;

import java.util.List;

import com.capgemini.assetmgmt.dtos.Employee;
import com.capgemini.assetmgmt.exceptions.AssetEmployeeException;

/*Interface for abstract methods of Admin Service Functions*/
public interface AssetEmployeeService {

	public Employee findEmployee(int empNo) throws AssetEmployeeException;
	public List<Employee> getEmployeeList() throws AssetEmployeeException;
}
