package com.capgemini.assetmgmt.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.assetmgmt.daos.AssetUserDAO;
import com.capgemini.assetmgmt.dtos.User;
import com.capgemini.assetmgmt.exceptions.AssetUserException;

@Service("assetUserService")
@Transactional/*(noRollbackFor = Exception.class)*/
public class AssetUserServiceImpl implements AssetUserService {

	@Resource(name="assetUserDao")
	private AssetUserDAO userDAO;

	/*
	 * 1. Check the user is valid or not.
	 * 2. Register the user in table.
	*/
	@Override
	public boolean isValidUser(User user)
			throws AssetUserException {
		boolean isCheck = userDAO.isValidUser(user);
		return isCheck;
	}

	@Override
	public boolean register(User user, String confirmPass) throws AssetUserException {
		return userDAO.register(user,confirmPass);
	}

}
