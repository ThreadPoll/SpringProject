package com.capgemini.assetmgmt.dtos;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Future;

@Entity(name="assetAllocation")
@Table(name="asset_asset_Allocation")
public class AssetAllocation {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="allocationIdGenerator")
	@SequenceGenerator(name="allocationIdGenerator", sequenceName="generate_allocation_id" , initialValue=10000)
	@Column
	private int allocationId;
	
	@ManyToOne
	@JoinColumn(name="assetId")
	private Asset asset;
	
	@ManyToOne
	@JoinColumn(name="empNo")
	private Employee employee;
	
	@Future(message="Allocation date cannot be before today's date")
	@Column
	private Date allocationDate;
	
	@Column
	private Date releaseDate;
	
	@Enumerated(EnumType.STRING)
	@Column
	private Status status;
	
	public AssetAllocation() {
	
	}

	public AssetAllocation(int allocationId, Asset asset, Employee employee,
			Date allocationDate, Date releaseDate, Status status) {
		super();
		this.allocationId = allocationId;
		this.asset = asset;
		this.employee = employee;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
		this.status = status;
	}

	public int getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}

	public Asset getAsset() {
		return asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AssetAllocation [allocationId=" + allocationId + ", asset="
				+ asset + ", employee=" + employee + ", allocationDate="
				+ allocationDate + ", releaseDate=" + releaseDate + ", status="
				+ status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((allocationDate == null) ? 0 : allocationDate.hashCode());
		result = prime * result + allocationId;
		result = prime * result + ((asset == null) ? 0 : asset.hashCode());
		result = prime * result
				+ ((employee == null) ? 0 : employee.hashCode());
		result = prime * result
				+ ((releaseDate == null) ? 0 : releaseDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AssetAllocation other = (AssetAllocation) obj;
		if (allocationDate == null) {
			if (other.allocationDate != null)
				return false;
		} else if (!allocationDate.equals(other.allocationDate))
			return false;
		if (allocationId != other.allocationId)
			return false;
		if (asset == null) {
			if (other.asset != null)
				return false;
		} else if (!asset.equals(other.asset))
			return false;
		if (employee == null) {
			if (other.employee != null)
				return false;
		} else if (!employee.equals(other.employee))
			return false;
		if (releaseDate == null) {
			if (other.releaseDate != null)
				return false;
		} else if (!releaseDate.equals(other.releaseDate))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

}
